# How LinkLens compares to existing URL checkers, and what it does differently

This page lists recurring weaknesses of popular link-checking services, based on published research and the
providers' own documentation, and states how LinkLens addresses each one.

**Read this first (honesty notes)**

- LinkLens has **not been benchmarked** against these services. Nothing here claims a higher detection rate.
  The comparison is about *design decisions* and *failure modes*, not accuracy numbers.
- Several of the blog posts cited are written by competing vendors (marked *vendor source*). Treat their
  numbers as claims, not neutral measurements.
- The existing services are far more capable in other ways (huge telemetry, live page rendering, human
  review). LinkLens is a lightweight, explainable, privacy-friendly first-look tool, not a replacement.

## 1. Mistakes found in existing tools, and the LinkLens fix

| # | Weakness in existing tools | Evidence | What LinkLens does instead |
|---|---|---|---|
| 1 | **Blocklist-only detection is reactive.** A URL is only flagged after someone has found and reported it, so brand-new phishing pages are missed in the first hours, exactly when most victims are hit. | USENIX research on the anti-phishing ecosystem: browser warnings rely on lists that are updated only after a detection; evasive phishing is slower to be blocked, and pages with advanced behaviour-based evasion were blocked 0% of the time in their test. Norn Labs (*vendor source*, Feb 2026) reported that Google Safe Browsing had flagged only 41 of 254 phishing sites they found. | The core engine analyses the **structure of the link and the wording of the message**, so it needs no prior report. Lists (local blocklist, optional Safe Browsing) are an add-on, never the foundation. |
| 2 | **Phishing hosted on trusted platforms** (GitHub Pages, Cloudflare, Google Sites, free hosts) slips through because the base domain has a good reputation and cannot simply be blocked. | Norn Labs (*vendor source*): 149 of its 254 phishing sites sat on well-known platforms. Also described in IsThisAScam's Safe Browsing write-up (*vendor source*). | A list of **abuse-prone hosting platforms** is treated as a risk modifier, not a trust signal. A brand name in a subdomain on such a host (`secure-hdfcbank-login.github.io`) is still flagged as impersonation. |
| 3 | **Aggregating many engines and trusting a vote.** Engines are correlated and disagree. A majority vote can be badly wrong. | Choo et al., *A Large Scale Study and Classification of VirusTotal Reports* (arXiv:2205.13155): scanners often disagree, and majority voting gave a false-positive rate that can reach 25.43% for phishing URLs. VirusTotal's own FAQ says it only aggregates, so a false positive can only be fixed by the individual vendor. | **No voting.** Each finding is a signal with a probability-like weight. Signals of the same kind get diminishing returns, and only *independent kinds* of evidence reinforce each other (noisy-OR, see `app/scoring.py`). A test asserts the combined score is lower than the naive sum. |
| 4 | **Opaque or expert-only output.** A raw list of 90 vendor verdicts, or pages of network logs, does not tell an ordinary person what to do. | guard.io comparison (*vendor source*) notes urlscan.io gives no simple safe/unsafe verdict and PhishTank is oriented to enterprise use. | Every score comes with **plain-language reasons, the evidence that triggered them, and concrete next steps**. Severity is shown as text, not colour alone. |
| 5 | **Stale or wrong data feeding the verdict.** | Bolster's comparison (*vendor source*) found urlscan.io reporting a site as malicious because an aggregated Safe Browsing record was out of date. | No cached verdicts are reused for content analysis. The page tells you **which checks ran, which were skipped and which failed** (`checks` in the response). A failed lookup is never silently shown as "clean". |
| 6 | **Community feeds contain noise.** | Study of Twitter phishing reports (arXiv:2111.07201): in a sample of 1,000 URLs, PhishTank had a 20.5% and OpenPhish a 4.1% false-positive rate. | Feeds are optional and used only as one signal category. A feed hit is shown as "listed in blocklist", and the other evidence is still displayed. |
| 7 | **Can't cope with short or redirected links.** | Bolster (*vendor source*): ScamAdviser could not handle a shortened/redirected URL in their test. | Shorteners are detected and explained. Optional expansion follows redirects **manually with per-hop validation** (see #10) and the destination is analysed and merged into the result. |
| 8 | **URL-only scope.** Most checkers ignore the message around the link, where much of the evidence lives (urgency, "verify your KYC", OTP requests). | Tools above are website/URL scanners by design. IsThisAScam (*vendor source*) positions on-demand text analysis as a gap-filler. | LinkLens scores the **message text and every link together**, adds a combined pattern bonus, and compares visible link text with the real destination (HTML and Markdown links). |
| 9 | **Look-alike domains and Unicode tricks.** Many checkers only compare against lists. | General phishing technique (homograph and typosquat attacks). | Built-in detection of mixed alphabets, punycode, digit/letter swaps (`paypa1`, `rnicrosoft`), one-typo squats, and brand names in subdomains, paths or combined with words like "secure". |
| 10 | **SSRF in tools that fetch submitted URLs.** A scanner that visits user-supplied addresses can be tricked into reaching internal services or cloud metadata. | Generic and well documented: for example the `ssrf_filter` library describes requests to `169.254.169.254` leaking cloud credentials. | The engine **never fetches anything by default**. The opt-in expander resolves DNS once, rejects the request if *any* answer is non-public, connects to that exact IP (no re-resolution race), follows redirects itself and re-checks every hop, allows only ports 80/443, parses obfuscated IPs like `2130706433`, caps hops and time, and never downloads the body. Covered by `tests/test_ssrf.py`. |
| 11 | **Privacy.** Public scan queues and shared submissions can expose what users paste. | urlscan.io offers public scans by design (see its service description). VirusTotal shares submissions with partners. | Analysis runs in memory. **Submitted text and URLs are never stored or logged.** Nothing is sent to third parties unless the operator turns on Safe Browsing and supplies a key, and the README says exactly what is sent. |
| 12 | **Overconfident wording.** "Safe", "clean", "0 detections". | VirusTotal's own documentation notes that URL scanner verdicts differ from antivirus verdicts and from each other. | LinkLens **never says "safe"**. The lowest verdict is "No strong phishing indicators found" with a reminder that new pages often look clean. HTTPS is explicitly described as *not* evidence of legitimacy. |
| 13 | **False alarms on genuine messages.** Naive keyword filters flag real bank SMS that say "never share your OTP". | Observed while building; a bank OTP message scored 34 until fixed. | Negation handling ("do not / never share your OTP") plus a regression test (`test_genuine_otp_message_is_not_flagged`). Official domains such as `accounts.google.com` do not trip "login" or "account" rules. |
| 14 | **Pathological input.** Regex-heavy checkers can be slowed down by crafted text (ReDoS). | Found in this project: dot-heavy input took about 5 s before bounding repetition; about 40 ms after. | Bounded regex repetition, input and link-count limits, a size cap, and a regression test with adversarial strings. |
| 15 | **Rate limiting that can be bypassed.** Trusting the left-most `X-Forwarded-For` value lets any client pick its own identity. | Common deployment mistake. | The limiter uses the entry added by your own proxy (counted from the right, `TRUSTED_PROXY_HOPS`). A test proves rotating a spoofed header does not reset the limit. |
| 16 | **Output rendered unsafely.** A checker echoes attacker-controlled strings back to the page. | Standard XSS risk for any tool that displays hostile input. | The UI uses `textContent` only, a strict Content-Security-Policy (`script-src 'self'`), and displays links **defanged** (`hxxp://evil[.]com`) so a tap cannot open them. |

## 2. What the established services still do better

Being straightforward about this matters more than the table above:

- **Live page analysis.** urlscan.io and others actually load pages in a sandbox, capture scripts, network calls
  and screenshots. LinkLens only reads the link and the message. It cannot see a cloaked page.
- **Scale and telemetry.** Google Safe Browsing and similar services learn from enormous volumes of real
  traffic. A recently reported campaign will be known to them before it is known to a small project.
- **Domain intelligence.** Services like ScamAdviser use many data sources (hosting, certificates, popularity,
  reviews). LinkLens has optional domain-age lookups only.
- **Visual brand detection.** Some vendors detect cloned logos and page layouts. LinkLens does not.

The sensible way to use LinkLens is as a **fast, explainable first look**, alongside a reputation service
for anything important.

## 3. Known limitations of LinkLens

- Heuristic scoring can produce false positives (a legitimate site that happens to have a brand name in its
  domain) and false negatives (a well-crafted phish on a clean-looking domain with calm wording).
- The built-in brand list covers about 60 brands, with extra weight on Indian banks, payments and government
  services. Extend `app/data/brands.json`.
- Message-wording rules are English with a little Hinglish. Extend `app/data/text_patterns.json`.
- No email header, attachment or QR-image analysis.
- Domain-age lookups use public RDAP and can fail or be rate-limited; failures are reported, not hidden.
- Google's Safe Browsing API terms limit it to non-commercial use; check the current terms (and the Web Risk
  API for commercial use) before enabling it in a product.

## Sources

- Choo et al., "A Large Scale Study and Classification of VirusTotal Reports on Phishing and Malware URLs", arXiv:2205.13155.
- "Canary in Twitter Mine: Collecting Phishing Reports from Experts and Non-experts", arXiv:2303.15847 (VirusTotal missed thousands of manually confirmed phishing URLs in their data).
- "Evaluating the effectiveness of Phishing Reports on Twitter", arXiv:2111.07201 (PhishTank and OpenPhish false-positive rates).
- USENIX ;login: article on the anti-phishing ecosystem and evasion (usenix.org/node/273654).
- VirusTotal documentation, "URL scanner verdict differ from its corresponding antivirus solution" (docs.virustotal.com/docs/urlscanner-differs).
- Norn Labs Huginn report, February 2026, as summarised by Gigazine (gigazine.net/gsc_news/en/20260316-google-safe-browsing). *Vendor source.*
- IsThisAScam, "Google Safe Browsing Limitations" (isthisascam.to/blog/google-safe-browsing-limitations). *Vendor source.*
- guard.io, "Best URL scanners" and "Best website safety checker tools". *Vendor source.*
- Bolster, "How Urlscan.io Alternatives CheckPhish and ScamAdviser Stack Up". *Vendor source.*
- `ssrf_filter` project README (github.com/vhx/ssrf_filter) for the SSRF risk description.
- Google Safe Browsing migration guide (developers.google.com/safe-browsing/reference/Migration.From.V4), stating non-commercial use.
