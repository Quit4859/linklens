import time

from app.analyzers.extract import extract_links, refang
from app.analyzers.text_analyzer import analyze_text
from app.scoring import combine, to_score


def ids(signals):
    return {s.id for s in signals}


# ---------------------------------------------------------------- text wording
def test_scam_message_is_flagged():
    sigs = analyze_text("URGENT: your account has been suspended. Verify your account and enter your OTP within 24 hours.")
    assert {"text_urgency", "text_threat", "text_credentials", "text_account_verification"} <= ids(sigs)
    assert to_score(combine(sigs)) >= 60


def test_genuine_otp_message_is_not_flagged():
    """Regression: a real bank OTP SMS used to score 34 because 'your OTP is' matched."""
    sigs = analyze_text("Your OTP is 482913. Do not share it with anyone. Never share your OTP, PIN or CVV. - HDFC Bank")
    assert "text_credentials" not in ids(sigs)
    assert to_score(combine(sigs)) < 15


def test_safety_advice_negation():
    assert "text_credentials" not in ids(analyze_text("We will never ask you to share your password or PIN."))
    assert "text_credentials" in ids(analyze_text("Please share your password and PIN to continue."))


def test_ordinary_chat_is_clean():
    assert analyze_text("Hey, are we still on for lunch at 1pm tomorrow? I'll bring the notes.") == []


def test_mixed_alphabet_words_detected():
    assert "text_mixed_script" in ids(analyze_text("Your Pаypal account needs attention"))  # Cyrillic a


# ---------------------------------------------------------------- extraction
def link_urls(text):
    return [l.url for l in extract_links(text)]


def test_extracts_scheme_www_and_bare_links():
    got = link_urls("see https://a.example.com/x?y=1, www.b.example.org and c.example.net/path.")
    assert got == ["https://a.example.com/x?y=1", "www.b.example.org", "c.example.net/path"]


def test_ignores_non_links():
    assert link_urls("e.g. see notes.txt or version 1.2.3 and mail me at someone@example.com") == []


def test_refang_and_defanged_links():
    assert refang("hxxps://evil[.]com/a") == "https://evil.com/a"
    assert link_urls("go to hxxp://evil[.]example[.]com now") == ["http://evil.example.com"]


def test_html_and_markdown_anchor_text_are_paired():
    html = link_urls('<a href="http://evil.top/x">www.paypal.com/security</a>')
    assert html == ["http://evil.top/x"]
    links = extract_links('<a href="http://evil.top/x">www.paypal.com/security</a> and [Sign in to PayPal](http://bad.example/p)')
    pairs = {l.url: l.anchor_text for l in links}
    assert pairs["http://evil.top/x"] == "www.paypal.com/security"
    assert pairs["http://bad.example/p"] == "Sign in to PayPal"


def test_trailing_punctuation_and_parentheses():
    assert link_urls("(see https://example.com/page).") == ["https://example.com/page"]
    assert link_urls("https://en.wikipedia.org/wiki/Foo_(bar)") == ["https://en.wikipedia.org/wiki/Foo_(bar)"]


def test_invisible_characters_are_stripped_by_engine():
    from app.analyzers.extract import strip_invisible

    cleaned, n = strip_invisible("pay​pal.com")
    assert cleaned == "paypal.com" and n == 1


def test_pathological_input_is_fast():
    """Regression: unbounded regex repetition made dot-heavy input quadratic (seconds)."""
    nasty = ["a." * 10000 + " http://" + "x" * 5000, ("a." * 3000 + " ") * 4, "[" * 20000, "-" * 20000]
    start = time.perf_counter()
    for text in nasty:
        extract_links(text)
    assert time.perf_counter() - start < 1.5
