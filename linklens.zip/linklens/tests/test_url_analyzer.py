import pytest

BENIGN = [
    "https://www.google.com/",
    "https://accounts.google.com/signin",          # "signin" subdomain/path on an official domain is normal
    "https://login.microsoftonline.com/common/oauth2",
    "https://www.google.co.in/search?q=weather",   # regional domains of known brands
    "https://www.amazon.com.au/gp/css/order-history",
    "https://github.com/anthropics",
    "https://en.wikipedia.org/wiki/Phishing",
    "https://example.com/",
    "https://www.python.org/downloads/",
    "https://www.bbc.co.uk/news",
    "https://docs.python.org/3/library/ipaddress.html",
    "https://stackoverflow.com/questions/1",
    "https://www.irctc.co.in/nget/train-search",
    "https://www.hdfcbank.com/personal/pay",
    "https://email.com/",                           # 1 letter from "gmail" but too short to treat as a typosquat
]


@pytest.mark.parametrize("url", BENIGN)
def test_benign_urls_stay_low(score_url, url):
    score, level, _ = score_url(url)
    assert level == "low", f"{url} scored {score}"
    assert score < 15


@pytest.mark.parametrize(
    "url, expected_signal, minimum",
    [
        ("http://paypal.com.secure-login.xyz/verify", "brand_in_subdomain", 75),
        ("https://paypa1.com/login", "brand_lookalike", 60),
        ("https://rnicrosoft.com/login", "brand_lookalike", 60),                 # rn -> m
        ("https://xn--pypal-4ve.com", "mixed_script", 90),                       # Cyrillic a inside "paypal"
        ("https://paypal.com@evil.example.net/", "userinfo_trick", 60),
        ("http://3232235777/a", "obfuscated_ip", 70),                            # decimal IP
        ("http://0xC0A80105/a", "obfuscated_ip", 70),                            # hex IP
        ("http://0300.0250.0.1/a", "obfuscated_ip", 70),                         # octal IP
        ("http://45.33.12.7/login.php", "ip_host", 50),
        ("https://secure-hdfcbank-login.github.io/", "brand_in_subdomain", 60),
        ("https://login-sbi-kyc-update.top/index.html", "brand_combosquat", 70),
        ("https://microsft.com", "brand_typosquat", 40),
        ("javascript:alert(1)", "dangerous_scheme", 70),
        ("https://files.example.org/invoice.pdf.exe", "double_extension", 40),
        ("http://evil.example/redirect?url=https://paypal.com&x=1", "redirect_param", 40),
    ],
)
def test_phishing_patterns_are_caught(score_url, url, expected_signal, minimum):
    score, _, ids = score_url(url)
    assert expected_signal in ids, f"{url}: got {ids}"
    assert score >= minimum, f"{url} scored only {score}"


def test_shortener_is_flagged_but_not_alarmist(score_url):
    score, level, ids = score_url("https://bit.ly/abc123")
    assert "shortener" in ids
    assert level == "low" and score > 0


def test_https_is_never_treated_as_proof_of_safety(score_url):
    score_http, _, _ = score_url("http://paypa1.com/login")
    score_https, _, _ = score_url("https://paypa1.com/login")
    assert score_https >= 60                      # HTTPS does not rescue a look-alike
    assert score_http >= score_https


def test_display_text_mismatch(score_url):
    score, _, ids = score_url("http://evil-pay.top/x", anchor="www.paypal.com/security")
    assert "display_mismatch" in ids and score >= 70


def test_defanged_input_is_still_analysed(score_url):
    score, _, ids = score_url("hxxps://secure-amazon-login[.]top/ap/signin")
    assert "brand_combosquat" in ids and score >= 60


def test_correlated_signals_do_not_stack_linearly(analyzer):
    """Several weak lure signals from one cheap kit must not look like several independent proofs."""
    from app.scoring import combine

    facts = analyzer.analyze("http://login-verify-secure-account.xyz/login/verify/account")
    naive_sum = sum(s.weight for s in facts.signals)
    assert combine(facts.signals) < min(1.0, naive_sum)


def test_garbage_input_never_raises(analyzer):
    for junk in ["", "   ", "http://", "http://[::1", "http://:80", "://", "http://a b c", "\u0000", "http://" + "x" * 5000]:
        analyzer.analyze(junk)  # must not raise
