"""The redirect expander is the only code that contacts user-supplied hosts, so it gets the strictest tests."""
import asyncio
import ipaddress

import httpx
import pytest

from app.analyzers import redirects
from app.analyzers.redirects import UnsafeTarget, ensure_public, expand, resolve_public


@pytest.mark.parametrize("ip", [
    "127.0.0.1", "10.0.0.5", "172.16.3.4", "192.168.1.1", "169.254.169.254", "0.0.0.0", "100.64.0.1",
    "224.0.0.1", "::1", "fe80::1", "fc00::1", "::ffff:127.0.0.1", "::ffff:10.0.0.1", "64:ff9b::7f00:1", "2002:7f00:1::1",
])
def test_internal_addresses_are_rejected(ip):
    with pytest.raises(UnsafeTarget):
        ensure_public(ipaddress.ip_address(ip))


@pytest.mark.parametrize("ip", ["8.8.8.8", "93.184.216.34", "2606:4700:4700::1111"])
def test_public_addresses_are_allowed(ip):
    ensure_public(ipaddress.ip_address(ip))


@pytest.mark.parametrize("host", ["2130706433", "0x7f.1", "0177.0.0.1", "127.1", "169.254.169.254", "[::1]".strip("[]")])
def test_obfuscated_loopback_literals_are_rejected(host):
    with pytest.raises(UnsafeTarget):
        asyncio.run(resolve_public(host, 80))


async def fake_resolver(host: str, port: int) -> list[str]:
    table = {"short.example": "93.184.216.34", "dest.example": "93.184.216.35", "rebind.example": "10.1.2.3"}
    if host not in table:                       # IP literals etc.: use the real validator (no DNS needed)
        return await resolve_public(host, port)
    ip = table[host]
    ensure_public(ipaddress.ip_address(ip))
    return [ip]


def run(url, handler, **kw):
    return asyncio.run(expand(url, resolver=fake_resolver, transport=httpx.MockTransport(handler), **kw))


def test_follows_redirect_chain_and_pins_ip():
    seen = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append((request.url.host, request.headers["host"]))
        if request.headers["host"] == "short.example":
            return httpx.Response(301, headers={"location": "https://dest.example/landing"})
        return httpx.Response(200)

    res = run("http://short.example/abc", handler)
    assert res.error is None
    assert res.final_url == "https://dest.example/landing"
    assert res.chain == ["http://short.example/abc", "https://dest.example/landing"]
    # we connected to the validated IPs, not to the hostnames (no second DNS lookup to race)
    assert seen == [("93.184.216.34", "short.example"), ("93.184.216.35", "dest.example")]


def test_redirect_to_cloud_metadata_is_blocked():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(302, headers={"location": "http://169.254.169.254/latest/meta-data/"})

    res = run("http://short.example/x", handler)
    assert res.error and "blocked" in res.error


def test_hostname_that_resolves_to_private_ip_is_blocked():
    called = []
    res = run("http://rebind.example/", lambda r: called.append(r) or httpx.Response(200))
    assert res.error and "blocked" in res.error
    assert called == []                      # no request was ever sent


def test_non_standard_ports_and_schemes_are_blocked():
    handler = lambda r: httpx.Response(200)  # noqa: E731
    assert "port" in run("http://short.example:6379/", handler).error
    assert "http(s)" in run("gopher://short.example/", handler).error
    assert "http(s)" in run("file:///etc/passwd", handler).error


def test_redirect_loops_are_capped():
    def handler(request):
        return httpx.Response(302, headers={"location": "http://short.example/again"})

    res = run("http://short.example/", handler, max_hops=4)
    assert res.error == "too many redirects"
    assert len(res.chain) <= 5


def test_expansion_disabled_by_default():
    from app.config import get_settings

    assert get_settings().enable_redirect_expansion is False
    assert get_settings().enable_network_lookups is False


def test_module_does_not_use_httpx_auto_redirects():
    import inspect

    src = inspect.getsource(redirects)
    assert "follow_redirects=False" in src and "follow_redirects=True" not in src
