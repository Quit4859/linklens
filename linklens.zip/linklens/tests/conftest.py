import pytest

from app.analyzers.url_analyzer import UrlAnalyzer
from app.scoring import combine, level_for, to_score


@pytest.fixture(scope="session")
def analyzer() -> UrlAnalyzer:
    return UrlAnalyzer()


@pytest.fixture(scope="session")
def score_url(analyzer):
    def _score(url: str, anchor: str | None = None):
        facts = analyzer.analyze(url, anchor)
        score = to_score(combine(facts.signals))
        return score, level_for(score), {s.id for s in facts.signals}

    return _score
