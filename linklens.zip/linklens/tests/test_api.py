import pytest
from fastapi.testclient import TestClient
from starlette.requests import Request

from app.main import app
from app.ratelimit import RateLimiter, client_ip


@pytest.fixture()
def client():
    with TestClient(app) as c:  # runs lifespan (creates engine + limiter)
        app.state.limiter = RateLimiter(1000)
        yield c


def test_health(client):
    body = client.get("/api/health").json()
    assert body["status"] == "ok"
    assert body["features"]["redirect_expansion"] is False


def test_index_and_static_are_served(client):
    assert "LinkLens" in client.get("/").text
    assert client.get("/static/app.js").status_code == 200
    assert client.get("/static/style.css").status_code == 200


def test_head_requests_are_supported(client):
    """Regression: uptime monitors and link-preview bots use HEAD; it used to return 405."""
    assert client.head("/").status_code == 200
    assert client.head("/api/health").status_code == 200


def test_security_headers(client):
    r = client.get("/")
    assert "script-src 'self'" in r.headers["content-security-policy"]
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "DENY"
    assert client.post("/api/analyze", json={"text": "x.com"}).headers["cache-control"] == "no-store"


def test_scam_sms_end_to_end(client):
    text = "URGENT: Your SBI account has been suspended. Verify KYC within 24 hours: http://sbi-kyc-update.xyz/login Enter your OTP."
    r = client.post("/api/analyze", json={"text": text}).json()
    assert r["level"] in {"high", "critical"} and r["score"] >= 75
    assert r["links"][0]["defanged"].startswith("hxxp://")
    assert "[.]" in r["links"][0]["defanged"]
    assert r["recommendations"] and r["top_reasons"]
    assert any(c["name"] == "Domain age (RDAP)" and c["status"] == "skipped" for c in r["checks"])  # honest about what did not run


def test_clean_link_is_low_and_never_called_safe(client):
    r = client.post("/api/analyze", json={"text": "https://www.python.org/"}).json()
    assert r["level"] == "low"
    assert "safe" not in r["verdict"].lower()
    assert "not a guarantee" in r["summary"].lower()


def test_bare_single_token_is_analysed(client):
    r = client.post("/api/analyze", json={"text": "paypal.com@evil.example.net"}).json()
    assert r["links"] and r["score"] >= 60


def test_mismatched_anchor_in_pasted_html(client):
    text = 'Dear customer, <a href="http://evil-pay.top/x">www.paypal.com/security</a>'
    r = client.post("/api/analyze", json={"text": text}).json()
    assert len(r["links"]) == 1 and r["score"] >= 70


def test_input_validation(client):
    assert client.post("/api/analyze", json={"text": ""}).status_code == 422
    assert client.post("/api/analyze", json={}).status_code == 422
    big = client.post("/api/analyze", content=b"x" * 500_000, headers={"content-type": "application/json", "content-length": "500000"})
    assert big.status_code == 413


def test_link_and_length_limits(client):
    many = " ".join(f"http://site{i}.example.com/p" for i in range(200))
    r = client.post("/api/analyze", json={"text": many}).json()
    assert len(r["links"]) == 25 and any("first 25 links" in n for n in r["notes"])


def test_server_never_reflects_markup_unescaped_in_html_endpoints(client):
    """The API returns JSON only; the front-end uses textContent. Make sure the API does not serve HTML."""
    r = client.post("/api/analyze", json={"text": "<script>alert(1)</script> http://x.example.com/<img src=x onerror=alert(1)>"})
    assert r.headers["content-type"].startswith("application/json")


def test_rate_limit_uses_trusted_proxy_hop_not_spoofed_header(client):
    app.state.limiter = RateLimiter(2)
    for expected in (200, 200, 429):
        r = client.post("/api/analyze", json={"text": "example.com"}, headers={"x-forwarded-for": "6.6.6.6, 2.2.2.2"})
        assert r.status_code == expected
    # A different spoofed left-most value must NOT reset the limit (same trusted entry 2.2.2.2).
    r = client.post("/api/analyze", json={"text": "example.com"}, headers={"x-forwarded-for": "7.7.7.7, 2.2.2.2"})
    assert r.status_code == 429 and "retry-after" in r.headers


def _req(xff: str | None):
    headers = [(b"x-forwarded-for", xff.encode())] if xff else []
    return Request({"type": "http", "headers": headers, "client": ("9.9.9.9", 1234)})


def test_client_ip_selection():
    assert client_ip(_req("6.6.6.6, 2.2.2.2"), 1) == "2.2.2.2"
    assert client_ip(_req("6.6.6.6, 2.2.2.2"), 0) == "9.9.9.9"
    assert client_ip(_req(None), 1) == "9.9.9.9"
