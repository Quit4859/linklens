# LinkLens

Paste a suspicious link or message and get an **explainable phishing risk score** (0-100) with the reasons,
the evidence, and what to do next. Built with FastAPI and plain HTML/JS (no front-end build step).

- Works on **brand-new, unlisted links** because it analyses the link structure and message wording, not just blocklists.
- Scores **the message and every link together**, including fake link text and look-alike domains.
- **Private by design:** nothing is stored or logged; links are never opened by default.
- Optional extras (all off by default): domain-age lookup (RDAP), Google Safe Browsing, safe short-link expansion.

See [`docs/COMPARISON.md`](docs/COMPARISON.md) for how it differs from existing checkers and what it cannot do.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
python -m pytest                                        # runs the full suite
uvicorn app.main:app --reload                           # http://127.0.0.1:8000
```

Requires Python 3.11+ (3.12 recommended).

## API

`POST /api/analyze`

```bash
curl -s localhost:8000/api/analyze -H 'content-type: application/json' \
  -d '{"text": "URGENT: your SBI account is suspended. Verify KYC: http://sbi-kyc-update.xyz/login"}'
```

Response (abridged, real output):

```json
{
  "score": 86, "level": "critical", "verdict": "Very likely phishing or a scam",
  "confidence": "high",
  "summary": "...", "recommendations": ["..."], "top_reasons": ["..."],
  "text_analysis": {"score": 35, "level": "medium", "signals": [{"id": "text_threat", "title": "Threat of account loss or penalty", "weight": 0.24, "severity": "low", "evidence": "account is suspended"}]},
  "links": [{"defanged": "hxxp://sbi-kyc-update[.]xyz/login", "score": 72, "level": "high",
             "signals": [{"id": "brand_combosquat", "title": "State Bank of India name combined with other words", "weight": 0.55}]}],
  "checks": [{"name": "Domain age (RDAP)", "status": "skipped", "note": "Network lookups are disabled on this server."}],
  "meta": {"elapsed_ms": 16.5, "links_found": 1}
}
```

`GET /api/health` returns status and which optional features are enabled.
Set `ENABLE_DOCS=true` to expose interactive API docs at `/docs`.

## Configuration (environment variables)

See [`.env.example`](.env.example). The important ones:

| Variable | Default | Purpose |
|---|---|---|
| `RATE_LIMIT_PER_MINUTE` | `30` | Per-client limit on `/api/analyze` |
| `TRUSTED_PROXY_HOPS` | `1` | Reverse proxies in front of the app (Render: 1, local: 0). Needed for correct rate limiting |
| `ENABLE_NETWORK_LOOKUPS` | `false` | RDAP domain age (and Safe Browsing if a key is set) |
| `GOOGLE_SAFE_BROWSING_KEY` | none | Optional. URLs are sent to Google; Google limits this API to non-commercial use |
| `ENABLE_REDIRECT_EXPANSION` | `false` | Lets the server follow short links (SSRF-guarded) |
| `MAX_TEXT_CHARS`, `MAX_LINKS` | `20000`, `25` | Input limits |

## Deploy on Render (from GitHub)

```bash
git init && git add . && git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<you>/linklens.git
git push -u origin main
```

Then in Render: **New -> Blueprint**, choose the repo. [`render.yaml`](render.yaml) sets the build command, start
command (`uvicorn app.main:app --host 0.0.0.0 --port $PORT`), health check and environment variables.
Alternatively create a **Web Service** manually with the same commands. Add `GOOGLE_SAFE_BROWSING_KEY` in the
dashboard only if you want it. On the free plan the service sleeps when idle, so the first request can be slow.

**Docker:** `docker build -t linklens . && docker run -p 8000:8000 linklens`

## How scoring works

1. Extract links (plain, `www.`, bare domains, defanged `hxxp://x[.]com`, HTML `<a>` and Markdown links).
2. Analyse each link statically: IP/obfuscated-IP hosts, `@` tricks, punycode and mixed alphabets, brand
   look-alikes, brand-in-subdomain, combo-squats, typosquats, risky endings, abused hosting, shorteners,
   risky file types, redirect parameters, fake link text.
3. Analyse the message wording in 12 categories (urgency, threats, credential requests, prizes, payments,
   authority impersonation, tech-support scams, job scams, ...), ignoring safety advice such as "never share your OTP".
4. Combine with **diminishing returns inside a category and noisy-OR across independent categories**
   (`app/scoring.py`), so correlated signals do not inflate the score.

Levels: 0-24 low, 25-49 medium, 50-74 high, 75-100 critical. LinkLens never labels anything "safe".

## Project layout

```
app/
  main.py            FastAPI app, security headers, rate limiting, static files
  engine.py          Orchestration and final scoring
  scoring.py         Noisy-OR scoring and levels
  analyzers/
    url_analyzer.py  Static URL analysis
    text_analyzer.py Message wording analysis
    extract.py       Link extraction and de-obfuscation
    homoglyph.py     Look-alike character handling
    reputation.py    Blocklist, RDAP, Safe Browsing (optional)
    redirects.py     SSRF-hardened short-link expansion (optional)
  data/              brands.json, text_patterns.json, lists.json, blocklist.txt  <- edit these to extend
  static/            index.html, style.css, app.js
tests/               (benign URLs, phishing patterns, SSRF, API, regressions)
scripts/update_blocklist.py   Optional feed downloader
docs/COMPARISON.md   Comparison with other providers
```

## Extending

- Add brands or official domains: `app/data/brands.json`
- Add scam phrases (any language): `app/data/text_patterns.json` (regex per category)
- Tune risky endings, hosting platforms, shorteners: `app/data/lists.json`
- Add a blocklist: `python scripts/update_blocklist.py` (check the feed's terms first)

## Security notes

- The server never fetches submitted URLs unless you enable redirect expansion; see `app/analyzers/redirects.py`.
- Strict CSP, `textContent`-only rendering, defanged link display, request size and rate limits.
- Submitted content is never logged. Logs contain only counts and scores.
- This is a risk indicator, not a guarantee. Do not use it as the only control for high-stakes decisions.

## License

MIT, see [LICENSE](LICENSE).
