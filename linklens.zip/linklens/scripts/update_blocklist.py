#!/usr/bin/env python3
"""Download a plain-text phishing URL feed into app/data/blocklist.txt (optional).

Usage:
    python scripts/update_blocklist.py                         # default: OpenPhish community feed
    python scripts/update_blocklist.py --url https://example.org/feed.txt

Check the feed provider's terms of use before redistributing or using a feed commercially.
A feed is only a *supplement*: most new phishing pages are not in any list yet, which is why the
heuristic engine does not depend on it.
"""
from __future__ import annotations

import argparse
import re
import sys
import urllib.request
from pathlib import Path

DEFAULT_URL = "https://openphish.com/feed.txt"
TARGET = Path(__file__).resolve().parent.parent / "app" / "data" / "blocklist.txt"
MAX_BYTES = 20 * 1024 * 1024


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", default=DEFAULT_URL)
    ap.add_argument("--out", type=Path, default=TARGET)
    args = ap.parse_args()

    req = urllib.request.Request(args.url, headers={"User-Agent": "LinkLens-blocklist-updater/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:  # noqa: S310 - operator-supplied URL, run by hand
        raw = resp.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        print("Feed is larger than 20 MB; refusing.", file=sys.stderr)
        return 1

    entries = sorted({line.strip() for line in raw.decode("utf-8", "ignore").splitlines()
                      if re.match(r"^https?://[^\s]+$", line.strip())})
    if not entries:
        print("No valid entries found; leaving the existing blocklist untouched.", file=sys.stderr)
        return 1

    header = f"# Generated from {args.url}\n# One entry per line; do not edit by hand.\n"
    args.out.write_text(header + "\n".join(entries) + "\n", encoding="utf-8")
    print(f"Wrote {len(entries):,} entries to {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
