"""Static URL analysis. Never touches the network: everything is derived from the string itself."""
from __future__ import annotations

import ipaddress
import math
import re
from collections import Counter
from dataclasses import dataclass, field
from urllib.parse import parse_qsl, unquote, urlsplit

from rapidfuzz.distance import Levenshtein

from .. import data_loader
from ..models import Signal
from ..utils import shorten
from .extract import EXTRACTOR, refang, strip_invisible
from .homoglyph import (
    decode_punycode_host,
    is_mixed_script,
    typo_skeleton,
    unicode_skeleton,
)


def severity_for(weight: float) -> str:
    if weight >= 0.5:
        return "high"
    if weight >= 0.3:
        return "medium"
    if weight >= 0.1:
        return "low"
    return "info"


def mk(sid: str, category: str, title: str, detail: str, weight: float, evidence: str | None = None) -> Signal:
    return Signal(
        id=sid,
        category=category,
        title=title,
        detail=detail,
        weight=round(weight, 3),
        severity=severity_for(weight),  # type: ignore[arg-type]
        evidence=shorten(evidence, 160) if evidence else None,
    )


@dataclass
class UrlFacts:
    original: str
    normalized: str | None = None
    host: str | None = None
    registered_domain: str | None = None
    signals: list[Signal] = field(default_factory=list)
    is_shortener: bool = False
    legit_brand: str | None = None


_TOKEN_SPLIT = re.compile(r"[.\-_]+")
_ASCII_DIGITS = re.compile(r"\d+", re.ASCII)
_EMAIL_IN_QUERY = re.compile(r"[\w.+-]{1,64}@[\w-]{1,63}\.[\w.-]{2,63}")
_DOUBLE_EXT = re.compile(r"\.(pdf|docx?|xlsx?|pptx?|jpe?g|png|gif|txt)\.(exe|scr|js|bat|cmd|vbs|apk|jar|lnk|hta|msi)$", re.I)
_DANGEROUS_SCHEME = re.compile(r"(?i)^\s*(javascript|data|vbscript|file):")
_COMMON_PORTS = {None, 80, 443}


def tokens(text: str) -> list[str]:
    return [t for t in _TOKEN_SPLIT.split(text.lower()) if t]


def shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = Counter(s)
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def parse_ipv4_loose(host: str) -> ipaddress.IPv4Address | None:
    """Parse IPv4 like a browser does (inet_aton): decimal, octal, hex, and 1-4 part forms."""
    parts = host.split(".")
    if not 1 <= len(parts) <= 4:
        return None
    nums: list[int] = []
    for p in parts:
        if not p:
            return None
        if re.fullmatch(r"0[xX][0-9a-fA-F]*", p):
            nums.append(int(p[2:] or "0", 16))
        elif re.fullmatch(r"0[0-7]+", p):
            nums.append(int(p, 8))
        elif _ASCII_DIGITS.fullmatch(p):
            nums.append(int(p))
        else:
            return None
    *head, last = nums
    if any(n > 255 for n in head) or last >= 256 ** (4 - len(head)):
        return None
    value = 0
    for n in head:
        value = (value << 8) | n
    value = (value << (8 * (4 - len(head)))) | last
    return ipaddress.IPv4Address(value)


def parse_ip_host(host: str):
    """Return (ip_object | None, is_canonical_form)."""
    if ":" in host:
        try:
            return ipaddress.IPv6Address(host.split("%", 1)[0]), True
        except ValueError:
            return None, True
    ip = parse_ipv4_loose(host)
    if ip is None:
        return None, True
    return ip, str(ip) == host


class UrlAnalyzer:
    def __init__(self) -> None:
        self.brands = data_loader.brands()
        self.lists = data_loader.lists()
        self.shorteners = set(self.lists["shorteners"])
        self.trusted_shorteners = set(self.lists["shortener_trusted"])
        self.bad_tlds: dict[str, float] = self.lists["suspicious_tlds"]
        self.abused_hosts = tuple(self.lists["abused_hosting"])
        self.lure_host = self.lists["lure_words_host"]
        self.lure_path = set(self.lists["lure_words_path"])
        self.risky_ext: dict[str, float] = self.lists["risky_extensions"]
        self.redirect_params = set(self.lists["redirect_params"])

        # domain -> brand name, for fast "is this an official domain?" checks
        self.domain_to_brand: dict[str, dict] = {}
        for b in self.brands:
            for d in b["domains"]:
                self.domain_to_brand[d] = b
            b["_names"] = sorted({k for k in b["keywords"]} | {EXTRACTOR(d).domain for d in b["domains"] if EXTRACTOR(d).domain})
            b["_skels"] = {kw: typo_skeleton(kw) for kw in b["_names"]}

    # ------------------------------------------------------------------ helpers
    def _official_brand(self, host: str, label: str, suffix: str) -> dict | None:
        parts = host.split(".")
        for i in range(len(parts) - 1):
            cand = ".".join(parts[i:])
            if cand in self.domain_to_brand:
                return self.domain_to_brand[cand]
        tld = suffix.rsplit(".", 1)[-1] if suffix else ""
        if len(tld) == 2:  # regional domains such as google.co.in, amazon.com.au
            for b in self.brands:
                if b.get("cctld_ok") and label in b["keywords"]:
                    return b
        return None

    @staticmethod
    def _kw_match(kw: str, toks: list[str]) -> bool:
        return any(t == kw or (len(kw) >= 6 and kw in t) for t in toks)

    def _brand_signals(self, *, label: str, label_u: str, subdomain: str, suffix: str, path_query: str,
                       host: str, official: dict | None) -> list[Signal]:
        found: list[Signal] = []
        sub_tokens = tokens(subdomain)
        label_tokens = tokens(label_u)
        path_tokens = tokens(re.sub(r"[/?&=#%]+", "-", path_query))
        # DNS labels are at most 63 chars; anything longer is junk and would only waste CPU.
        skel_cache = {c: typo_skeleton(c) for c in {label_u, *label_tokens} if 4 <= len(c) <= 63}

        for b in self.brands:
            if b is official:
                continue
            name = b["name"]
            hit: Signal | None = None

            # 1) homograph / look-alike spelling: "paypa1", "раypal" (Cyrillic а), "rnicrosoft"
            for cand, cand_skel in skel_cache.items():
                for kw in b["_names"]:
                    if len(kw) < 4 or cand == kw:
                        continue
                    if cand_skel == b["_skels"][kw]:
                        non_ascii = any(ord(c) > 127 for c in cand)
                        hit = mk("brand_lookalike", "brand", f"Look-alike of {name}",
                                 f"The domain name is spelled to resemble “{kw}” using "
                                 f"{'look-alike characters from another alphabet' if non_ascii else 'swapped characters (like 1 for l, rn for m)'}.",
                                 0.85 if non_ascii else 0.75, evidence=f"{label_u}.{suffix} ≈ {kw}")
                        break
                    if (len(cand) >= 6 and len(kw) >= 6 and (Levenshtein.distance(cand, kw) == 1
                            or (len(cand) >= 9 and len(kw) >= 9 and Levenshtein.distance(cand, kw) == 2))):
                        hit = mk("brand_typosquat", "brand", f"One typo away from {name}",
                                 f"“{cand}” differs from “{kw}” by only one or two letters, a classic typosquat. "
                                 "(It could also be an unrelated legitimate site with a similar name.)",
                                 0.5, evidence=f"{cand}.{suffix} vs {kw}")
                        break
                if hit:
                    break

            # 2) the official brand name used inside someone else's domain
            if hit is None:
                strong = any(len(k) >= 6 for k in b["keywords"])
                weight_scale = 1.0 if strong else 0.8
                full_domain_in_sub = any(d in subdomain.lower() for d in b["domains"] if len(d) >= 6)
                if any(self._kw_match(k, sub_tokens) for k in b["keywords"]):
                    hit = mk("brand_in_subdomain", "brand", f"{name} name used as a subdomain",
                             "The brand appears before the real domain name. Only the part right before the "
                             f"final domain ({label_u}.{suffix}) decides who owns this site.",
                             (0.72 if full_domain_in_sub else 0.6) * weight_scale,
                             evidence=f"{host}  → real domain: {label_u}.{suffix}")
                elif any(label_u == k for k in b["keywords"]):
                    gtld = len(suffix.rsplit(".", 1)[-1]) != 2
                    short = all(len(k) <= 5 for k in b["keywords"])
                    w = (0.28 if short else 0.5) if gtld else (0.18 if short else 0.3)
                    hit = mk("brand_other_tld", "brand", f"{name} name on an unofficial domain",
                             f"“{label_u}.{suffix}” is not one of {name}’s known domains.",
                             w, evidence=f"{label_u}.{suffix}")
                elif any(self._kw_match(k, label_tokens) for k in b["keywords"]):
                    hit = mk("brand_combosquat", "brand", f"{name} name combined with other words",
                             "Phishing domains often glue a brand to words like “secure” or “login”. "
                             f"The real owner of {label_u}.{suffix} is not {name}.",
                             0.55 * weight_scale, evidence=f"{label_u}.{suffix}")
                elif any(d in path_query.lower() for d in b["domains"] if len(d) >= 6):
                    hit = mk("brand_in_path", "brand", f"{name} domain pasted into the link path",
                             "A trusted domain is written after the real host to make the link look familiar.",
                             0.4, evidence=shorten(path_query, 100))
                elif any(len(k) >= 6 and k in path_tokens for k in b["keywords"]):
                    hit = mk("brand_in_path", "brand", f"{name} named in the link path",
                             "The brand appears in the path, but the site itself is not run by that brand.",
                             0.22, evidence=shorten(path_query, 100))
            if hit:
                found.append(hit)

        found.sort(key=lambda s: s.weight, reverse=True)
        return found[:2]

    # ------------------------------------------------------------------ main entry
    def analyze(self, raw: str, anchor_text: str | None = None) -> UrlFacts:
        facts = UrlFacts(original=raw)
        sigs = facts.signals

        s, invisible = strip_invisible(refang(raw.strip()))
        if invisible:
            sigs.append(mk("invisible_chars", "obfuscation", "Hidden characters inside the link",
                           f"{invisible} invisible character(s) were removed. They are used to dodge filters.", 0.3))

        if _DANGEROUS_SCHEME.match(s):
            scheme = s.split(":", 1)[0].lower()
            sigs.append(mk("dangerous_scheme", "scheme", f"Non-web link type ({scheme}:)",
                           "This is not a normal web address; it can run code or embed a page directly in the link.",
                           0.8, evidence=s))
            return facts

        if len(s) > 4096:
            sigs.append(mk("giant_url", "structure", "Extremely long link", "Over 4,000 characters; analysed only in part.", 0.15))
            s = s[:4096]

        scheme_assumed = "://" not in s
        if "\\" in s.split("?", 1)[0]:
            sigs.append(mk("backslash", "obfuscation", "Backslashes in the link",
                           "Browsers treat \\ like /, while some filters do not. Seen in evasion attempts.", 0.15))
            s = s.replace("\\", "/")
        url = ("http://" + s.lstrip("/")) if scheme_assumed else s

        try:
            parts = urlsplit(url)
            host_raw = parts.hostname
            port = parts.port
        except ValueError:
            sigs.append(mk("malformed", "structure", "Malformed link", "The link cannot be parsed as a valid web address.", 0.3, evidence=s))
            return facts
        if not host_raw:
            sigs.append(mk("malformed", "structure", "No host found", "The link has no domain name.", 0.3, evidence=s))
            return facts
        if parts.scheme.lower() not in {"http", "https", "ftp"}:
            sigs.append(mk("odd_scheme", "scheme", f"Unusual protocol ({parts.scheme})", "Most phishing uses plain web links.", 0.2))

        facts.normalized = url.split("#", 1)[0]
        host = host_raw.lower().rstrip(".")
        if "%" in host:
            decoded = unquote(host)
            sigs.append(mk("encoded_host", "obfuscation", "Percent-encoded characters in the domain",
                           "Legitimate sites almost never encode their domain name.", 0.35, evidence=f"{host} → {decoded}"))
            host = decoded.lower()

        # ---- credentials in the authority part: https://paypal.com@evil.com
        if "@" in parts.netloc:
            userinfo = parts.netloc.rpartition("@")[0]
            looks_like_domain = bool(re.search(r"\.[a-z]{2,}", userinfo, re.I)) or "://" in userinfo
            sigs.append(mk("userinfo_trick", "deception", "Fake domain before an @ sign",
                           "Everything before the @ is ignored by the browser. The real destination is "
                           f"“{host}”, not “{userinfo}”.",
                           0.7 if looks_like_domain else 0.4, evidence=f"Real host: {host}"))

        ip, canonical = parse_ip_host(host)
        facts.host = host
        port_is_odd = port not in _COMMON_PORTS
        if ip is not None:
            if not canonical:
                sigs.append(mk("obfuscated_ip", "host", "IP address disguised as a number",
                               f"The host is an IP address written in an unusual form ({host} → {ip}).", 0.8, evidence=str(ip)))
            elif not ip.is_global:
                sigs.append(mk("private_ip", "host", "Points to a private or internal address",
                               "A message from the internet should not send you to a local or internal address.", 0.4, evidence=str(ip)))
            else:
                sigs.append(mk("ip_host", "host", "Uses a raw IP address instead of a domain name",
                               "Legitimate services almost always use a domain name; raw IPs are common in phishing kits.", 0.55, evidence=str(ip)))
            facts.registered_domain = str(ip)
            if port_is_odd:
                sigs.append(mk("odd_port", "host", f"Unusual port ({port})", "Web links normally use the default port.", 0.12))
            self._common_url_signals(parts, facts, host, official=None, scheme_assumed=scheme_assumed)
            self._anchor_signals(facts, anchor_text, None)
            return facts

        # ---- IDN / punycode
        ascii_host = host
        unicode_host = host
        if any(ord(c) > 127 for c in host):
            try:
                ascii_host = host.encode("idna").decode("ascii")
            except UnicodeError:
                ascii_host = host
        if "xn--" in ascii_host:
            unicode_host = decode_punycode_host(ascii_host)
        if ascii_host != host or "xn--" in ascii_host:
            mixed = any(is_mixed_script(lbl) for lbl in unicode_host.split("."))
            if mixed:
                sigs.append(mk("mixed_script", "homograph", "Letters from different alphabets mixed in one word",
                               "This is the signature of a homograph attack: characters that look Latin but are not.",
                               0.8, evidence=f"{unicode_host}  ({ascii_host})"))
            else:
                sigs.append(mk("idn", "homograph", "Internationalised domain name",
                               "The domain uses non-ASCII characters. Common for legitimate local-language sites, "
                               "but also used to imitate brands.", 0.18, evidence=f"{unicode_host}  ({ascii_host})"))

        ext = EXTRACTOR(ascii_host)
        label_ascii, suffix, subdomain = ext.domain, ext.suffix, ext.subdomain
        if not suffix:
            sigs.append(mk("unknown_tld", "host", "Unrecognised domain ending",
                           "The part after the last dot is not a known top-level domain.", 0.3, evidence=host))
            facts.registered_domain = host
            self._common_url_signals(parts, facts, host, official=None, scheme_assumed=scheme_assumed)
            return facts

        reg = f"{label_ascii}.{suffix}"
        facts.registered_domain = reg
        label_u = decode_punycode_host(label_ascii)
        subdomain_u = decode_punycode_host(subdomain)
        official = self._official_brand(host, label_u, suffix)
        if official:
            facts.legit_brand = official["name"]
            sigs.append(Signal(id="ok_official_domain", category="trust", title=f"Official {official['name']} domain",
                               detail="This domain is on the built-in list of the brand's own domains. "
                                      "The link can still be misused (for example open redirects), so check where it leads.",
                               weight=0.0, severity="info", evidence=reg))

        path_query = unquote(parts.path + ("?" + parts.query if parts.query else ""))

        if not official:
            sigs.extend(self._brand_signals(label=label_ascii, label_u=label_u, subdomain=subdomain_u, suffix=suffix,
                                            path_query=path_query, host=unicode_host, official=official))

            # domain-structure heuristics (skipped for official domains, which legitimately have deep hosts)
            tld_w = self.bad_tlds.get(suffix.rsplit(".", 1)[-1])
            if tld_w:
                sigs.append(mk("risky_tld", "host", f"Domain ending .{suffix.rsplit('.', 1)[-1]} is heavily abused",
                               "Weak signal on its own: many legitimate sites use this ending too, but it is over-represented in scams.",
                               tld_w, evidence=reg))
            depth = len([x for x in subdomain.split(".") if x])
            if depth >= 4:
                sigs.append(mk("deep_subdomain", "structure", f"{depth} subdomain levels",
                               "Long chains of subdomains push the real domain out of sight on small screens.", 0.18, evidence=host))
            elif depth == 3:
                sigs.append(mk("deep_subdomain", "structure", "3 subdomain levels", "Slightly unusual nesting.", 0.08, evidence=host))
            if unicode_host.replace("xn--", "").count("-") >= 3:
                sigs.append(mk("many_hyphens", "structure", "Many hyphens in the domain",
                               "Stringing words together with hyphens is typical for throw-away phishing domains.", 0.15, evidence=host))
            if len(_ASCII_DIGITS.findall(label_ascii)) and sum(c.isdigit() for c in label_ascii) >= 4:
                sigs.append(mk("digit_heavy", "structure", "Lots of digits in the domain name", "Auto-generated domains often contain number runs.", 0.1, evidence=label_ascii))
            vowels = sum(c in "aeiou" for c in label_ascii) / max(1, len(label_ascii))
            ent = shannon_entropy(label_ascii)
            if "-" not in label_ascii and ((len(label_ascii) >= 12 and ent > 3.4 and vowels < 0.22) or (len(label_ascii) >= 18 and ent > 3.7)):
                sigs.append(mk("random_looking", "structure", "Domain name looks randomly generated",
                               "High character randomness is typical for algorithmically generated domains.", 0.15, evidence=label_ascii))
            if len(host) > 60:
                sigs.append(mk("long_host", "structure", "Unusually long domain", "Very long host names are often used to hide the real domain.", 0.12, evidence=host))

            # lure words inside the host name
            host_tokens = tokens(subdomain_u) + tokens(label_u)
            lure_hits = sorted({w for w in self.lure_host
                                if (len(w) >= 5 and any(w in t for t in host_tokens)) or w in host_tokens})
            if lure_hits:
                w = 0.10 if len(lure_hits) == 1 else 0.18 if len(lure_hits) == 2 else 0.26
                sigs.append(mk("lure_words_host", "lure", "Credential-style words in the domain name",
                               "Words like login, verify or secure in a domain name are a common lure.", w, evidence=", ".join(lure_hits)))

        # hosting abuse (applies even to "official" parent domains such as sites.google.com)
        for plat in self.abused_hosts:
            if host == plat or host.endswith("." + plat):
                sigs.append(mk("abused_hosting", "hosting", f"Hosted on a free/shared platform ({plat})",
                               "Attackers publish phishing pages on trusted platforms so the base domain looks reputable. "
                               "The platform being legitimate says nothing about this particular page.", 0.15, evidence=host))
                break

        if host in self.shorteners or any(host.endswith("." + x) for x in self.shorteners):
            facts.is_shortener = True
            trusted = host in self.trusted_shorteners
            sigs.append(mk("shortener", "obfuscation", "URL shortener hides the real destination",
                           "You cannot see where this leads without following it. Use a link expander or ask the sender for the full address.",
                           0.1 if trusted else 0.22, evidence=host))

        if port_is_odd:
            sigs.append(mk("odd_port", "host", f"Unusual port ({port})", "Web links normally use the default port.", 0.12))

        self._common_url_signals(parts, facts, host, official=official, scheme_assumed=scheme_assumed)
        self._anchor_signals(facts, anchor_text, official)
        return facts

    # ------------------------------------------------------------------ path / query / scheme
    def _common_url_signals(self, parts, facts: UrlFacts, host: str, *, official, scheme_assumed: bool) -> None:  # noqa: ANN001
        sigs = facts.signals
        if parts.scheme.lower() == "http" and not scheme_assumed:
            sigs.append(mk("no_https", "transport", "Not encrypted (http://)",
                           "Missing HTTPS is a warning sign, but note that HTTPS alone does not make a site legitimate.", 0.08))

        path = unquote(parts.path or "")
        query = parts.query or ""

        last = path.rstrip("/").rsplit("/", 1)[-1].lower()
        if "." in last:
            ext = last.rsplit(".", 1)[-1]
            weight = self.risky_ext.get(ext)
            if _DOUBLE_EXT.search(last):
                sigs.append(mk("double_extension", "payload", "Disguised file type", "A document-like name hides an executable extension.", 0.6, evidence=last))
            elif weight and not (official and ext in {"html", "htm", "svg", "zip"}):
                sigs.append(mk("risky_extension", "payload", f"Links to a .{ext} file",
                               "Direct downloads of this file type are a common malware vector." if weight >= 0.3
                               else "Downloadable file or HTML page: check it is what you expect.", weight, evidence=last))

        if not official:
            words = {t for t in tokens(re.sub(r"[/?&=#%+]+", "-", path + "?" + query))}
            hits = sorted(self.lure_path & words)
            if hits:
                sigs.append(mk("lure_words_path", "lure", "Credential-style words in the link path",
                               "Words like login or verify in the path are common in credential-harvesting pages.",
                               0.05 if len(hits) < 3 else 0.10, evidence=", ".join(hits)))

        if query:
            try:
                pairs = parse_qsl(query[:4000], keep_blank_values=False, max_num_fields=60)
            except ValueError:
                pairs = []
            for key, value in pairs:
                if key.lower() in self.redirect_params and re.match(r"(?i)^(https?:)?//|^[\w-]+(\.[\w-]+)+(/|$)", unquote(value)):
                    tgt = unquote(value)
                    tgt_host = urlsplit(tgt if "//" in tgt else "//" + tgt).hostname or ""
                    if tgt_host and tgt_host.lower() != host:
                        sigs.append(mk("redirect_param", "obfuscation", "Link carries another address to jump to",
                                       "Redirect parameters let a trusted-looking domain forward you somewhere else.",
                                       0.22, evidence=f"{key}= {shorten(tgt, 90)}"))
                        break
            if _EMAIL_IN_QUERY.search(unquote(query)):
                sigs.append(mk("email_in_query", "lure", "A personal email address is embedded in the link",
                               "Phishing kits pre-fill the victim's address to look personal.", 0.12))

        if len(parts.geturl()) > 500:
            sigs.append(mk("long_url", "structure", "Very long link", "Long links can bury the suspicious part.", 0.08))
        elif len(parts.geturl()) > 200:
            sigs.append(mk("long_url", "structure", "Long link", "Slightly unusual length.", 0.05))

    # ------------------------------------------------------------------ anchor text vs. real target
    def _anchor_signals(self, facts: UrlFacts, anchor: str | None, official: dict | None) -> None:
        if not anchor or not facts.registered_domain:
            return
        anchor = anchor.strip()
        m = re.search(r"(?i)(?:https?://)?((?:[\w-]+\.)+[a-z]{2,24})(?::\d+)?(?:/\S*)?", anchor)
        if m:
            shown = EXTRACTOR(m.group(1))
            shown_reg = f"{shown.domain}.{shown.suffix}" if shown.suffix else m.group(1)
            if shown_reg.lower() != facts.registered_domain.lower():
                facts.signals.append(mk("display_mismatch", "deception", "Link text shows a different site than the link opens",
                                        f"The visible text says {shown_reg}, but the link goes to {facts.registered_domain}.",
                                        0.65, evidence=shorten(anchor, 80)))
                return
        low = anchor.lower()
        toks = tokens(low)
        for b in self.brands:
            if official is b:
                continue
            if any(self._kw_match(k, toks) for k in b["keywords"] if len(k) >= 4):
                facts.signals.append(mk("anchor_brand_mismatch", "deception", f"Text mentions {b['name']} but the link goes elsewhere",
                                        f"The link goes to {facts.registered_domain}, which is not a known {b['name']} domain.",
                                        0.35, evidence=shorten(anchor, 80)))
                return
