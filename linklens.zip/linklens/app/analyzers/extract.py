"""Find links in free text, undo common obfuscation, and pair links with their visible text."""
from __future__ import annotations

import re
from dataclasses import dataclass
from html.parser import HTMLParser

import tldextract

# Offline-only: use the public-suffix snapshot bundled with tldextract. No network at import or runtime.
EXTRACTOR = tldextract.TLDExtract(suffix_list_urls=(), cache_dir=None)

INVISIBLE = re.compile("[​-‏‪-‮⁠-⁤﻿­᠎]")

_DANGEROUS = re.compile(r"(?i)\b(?:javascript|data|vbscript):[^\s<>\"']{1,2000}")
_SCHEME_URL = re.compile(r"(?i)\b(?:https?|ftp)://[^\s<>\"'`]{1,2000}")
_WWW_URL = re.compile(r"(?i)(?<![\w@/.:-])www\.[^\s<>\"'`]{1,2000}")
# Bare "example.com/path". The TLD is validated against the public-suffix list afterwards, so
# "e.g." or "file.txt" are rejected. Each repeated group must end in a dot => no catastrophic backtracking.
_BARE = re.compile(
    r"(?i)(?<![\w@/.:%-])(?:[\w-]{1,63}\.){1,12}(?:[^\W\d_]{2,24}|xn--[a-z0-9-]{2,59})"
    r"(?::\d{2,5})?(?:/[^\s<>\"'`]{0,2000})?(?![\w@-])"
)
_MD_LINK = re.compile(r"\[([^\]\n]{1,200})\]\(\s*([^)\s]{1,2000})\s*\)")


@dataclass
class ExtractedLink:
    url: str
    anchor_text: str | None = None


def strip_invisible(text: str) -> tuple[str, int]:
    cleaned, n = INVISIBLE.subn("", text)
    return cleaned, n


def refang(text: str) -> str:
    """Undo 'defanged' indicators like hxxp://evil[.]com so they are analysed as real links."""
    text = re.sub(r"(?i)\bh[xt]{2}p(s?)(?=\s*(?::|\[:\]|\[://\]))", r"http\1", text)
    text = text.replace("[://]", "://").replace("[:]", ":")
    text = re.sub(r"(?i)\[\s*(?:\.|dot)\s*\]|\(\s*(?:\.|dot)\s*\)|\{\s*(?:\.|dot)\s*\}", ".", text)
    return text


def trim_url(url: str) -> str:
    while url:
        last = url[-1]
        if last in ".,;:!?'\">":
            url = url[:-1]
        elif last == "]" and "[" not in url:
            url = url[:-1]
        elif last == "}" and "{" not in url:
            url = url[:-1]
        elif last == ")" and url.count(")") > url.count("("):
            url = url[:-1]
        else:
            break
    return url


def _valid_bare_host(candidate: str) -> bool:
    host_part = re.split(r"[/:]", candidate, maxsplit=1)[0]
    ext = EXTRACTOR(host_part)
    return bool(ext.domain and ext.suffix)


class _AnchorParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.anchors: list[tuple[str, str]] = []
        self._href: str | None = None
        self._buf: list[str] = []

    def handle_starttag(self, tag, attrs):  # noqa: ANN001
        if tag == "a":
            self._href = dict(attrs).get("href") or ""
            self._buf = []

    def handle_data(self, data):  # noqa: ANN001
        if self._href is not None:
            self._buf.append(data)

    def handle_endtag(self, tag):  # noqa: ANN001
        if tag == "a" and self._href is not None:
            self.anchors.append((self._href.strip(), " ".join("".join(self._buf).split())))
            self._href = None


def extract_links(text: str) -> list[ExtractedLink]:
    """Return unique links in order of appearance, with anchor text where it is known."""
    found: list[ExtractedLink] = []
    seen: set[str] = set()

    def add(url: str, anchor: str | None = None) -> None:
        url = trim_url(url.strip())
        if not url:
            return
        key = url.lower()
        if key in seen:
            # keep the anchor text if we learn it later
            if anchor:
                for item in found:
                    if item.url.lower() == key and not item.anchor_text:
                        item.anchor_text = anchor
            return
        seen.add(key)
        found.append(ExtractedLink(url=url, anchor_text=anchor or None))

    text = refang(text)
    anchor_texts: set[str] = set()

    # 1) HTML anchors and Markdown links carry link text we can compare against the real target.
    if re.search(r"(?i)<a\s", text):
        parser = _AnchorParser()
        try:
            parser.feed(text)
            parser.close()
        except Exception:  # noqa: BLE001 - malformed HTML must never break analysis
            pass
        for href, anchor in parser.anchors:
            if href and not href.startswith(("#", "mailto:", "tel:")):
                add(href, anchor)
                anchor_texts.add(trim_url(anchor).lower())
    for m in _MD_LINK.finditer(text):
        add(m.group(2), m.group(1))
        anchor_texts.add(trim_url(m.group(1)).lower())

    # 2) Plain URLs.
    spans: list[tuple[int, int]] = []
    for pattern in (_DANGEROUS, _SCHEME_URL, _WWW_URL):
        for m in pattern.finditer(text):
            spans.append(m.span())
            if trim_url(m.group(0)).lower() in anchor_texts:
                continue  # it is just the visible text of a link we already have
            add(m.group(0))

    def inside_existing(start: int, end: int) -> bool:
        return any(s <= start and end <= e for s, e in spans)

    for m in _BARE.finditer(text):
        if inside_existing(*m.span()):
            continue
        cand = trim_url(m.group(0))
        if cand.lower() in anchor_texts:
            continue
        if _valid_bare_host(cand):
            add(cand)

    return found
