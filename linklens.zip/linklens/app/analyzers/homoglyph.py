"""Lookalike / homograph helpers (pure stdlib, no network)."""
from __future__ import annotations

import unicodedata

# Characters from other scripts (and a few Latin extensions) that render like ASCII letters.
_CONFUSABLES = {
    # Cyrillic
    "а": "a", "в": "b", "с": "c", "ԁ": "d", "е": "e", "һ": "h", "і": "i", "ї": "i", "ј": "j", "к": "k",
    "ӏ": "l", "м": "m", "н": "h", "о": "o", "р": "p", "ԛ": "q", "ѕ": "s", "т": "t", "у": "y", "х": "x",
    "ѵ": "v", "ԝ": "w", "ь": "b", "ґ": "r", "ɡ": "g",
    # Greek
    "α": "a", "β": "b", "ε": "e", "ι": "i", "κ": "k", "ν": "v", "ο": "o", "ρ": "p", "τ": "t", "υ": "u",
    "χ": "x", "γ": "y", "η": "n", "ω": "w",
    # Latin look-alikes
    "ı": "i", "ɑ": "a", "ⅼ": "l", "ℓ": "l", "ǀ": "l", "ο": "o", "ơ": "o", "ɩ": "i", "ʋ": "v", "ƅ": "b",
}

# ASCII tricks: digits/symbols standing in for letters.
_ASCII_TRICKS = str.maketrans({"0": "o", "1": "l", "3": "e", "5": "s", "$": "s", "@": "a", "i": "l", "4": "a"})
_SEQUENCES = (("rn", "m"), ("vv", "w"), ("cl", "d"), ("cI", "d"))


def unicode_skeleton(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).lower()
    return "".join(_CONFUSABLES.get(ch, ch) for ch in text)


def typo_skeleton(text: str) -> str:
    """Collapse visually confusable letters so 'paypa1', 'paypaI' and 'раураl' all equal 'paypal'."""
    s = unicode_skeleton(text)
    for a, b in _SEQUENCES:
        s = s.replace(a, b)
    return s.translate(_ASCII_TRICKS)


def script_of(ch: str) -> str:
    try:
        name = unicodedata.name(ch)
    except ValueError:
        return "UNKNOWN"
    first = name.split(" ", 1)[0]
    return first if first in {
        "LATIN", "CYRILLIC", "GREEK", "ARABIC", "HEBREW", "ARMENIAN", "DEVANAGARI", "THAI", "HANGUL",
        "HIRAGANA", "KATAKANA", "CJK", "GEORGIAN", "BENGALI", "TAMIL", "TELUGU",
    } else "OTHER"


def scripts_in(text: str) -> set[str]:
    return {script_of(ch) for ch in text if ch.isalpha()}


def is_mixed_script(text: str) -> bool:
    scripts = scripts_in(text)
    scripts.discard("OTHER")
    return len(scripts) > 1


def decode_punycode_host(ascii_host: str) -> str:
    """'xn--pypal-4ve.com' -> 'pаypal.com'. Falls back to the input on any error."""
    labels = []
    for label in ascii_host.split("."):
        if label.lower().startswith("xn--"):
            try:
                labels.append(label.encode("ascii").decode("idna"))
                continue
            except (UnicodeError, ValueError):
                pass
        labels.append(label)
    return ".".join(labels)
