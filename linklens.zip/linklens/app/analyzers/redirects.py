"""Optional, SSRF-hardened expansion of URL shorteners.

Off by default. When enabled it is the ONLY place the server contacts a user-supplied address, so it is
deliberately paranoid. Mistakes this avoids (they are the classic SSRF bugs in "link checker" tools):

  1. Checking the hostname and then letting the HTTP client resolve it again (DNS rebinding / TOCTOU).
     -> We resolve once, validate EVERY returned address, then connect to that exact IP.
  2. Letting the HTTP client follow redirects on its own, so a public URL can bounce to
     http://169.254.169.254/ (cloud metadata). -> Redirects are followed manually and each hop is re-validated.
  3. Missing odd IP spellings (http://2130706433/, 0x7f.1, IPv4-mapped IPv6). -> Browser-style IP parsing is reused.
  4. Unlimited hops, size or time. -> Hop, time and byte limits; the response body is never downloaded.
"""
from __future__ import annotations

import asyncio
import ipaddress
import socket
from dataclasses import dataclass, field
from typing import Awaitable, Callable
from urllib.parse import urljoin, urlsplit

import httpx

from .url_analyzer import parse_ip_host

_ALLOWED_PORTS = {None, 80, 443}
_REDIRECT_CODES = {301, 302, 303, 307, 308}
_BLOCKED_V6 = tuple(ipaddress.ip_network(n) for n in ("64:ff9b::/96", "2002::/16", "2001::/32", "fc00::/7"))

Resolver = Callable[[str, int], Awaitable[list[str]]]


class UnsafeTarget(Exception):
    pass


def ensure_public(ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> None:
    if isinstance(ip, ipaddress.IPv6Address):
        if ip.ipv4_mapped is not None:
            ip = ip.ipv4_mapped
        elif any(ip in net for net in _BLOCKED_V6):
            raise UnsafeTarget(f"address {ip} is in a blocked range")
    if not ip.is_global or ip.is_multicast:
        raise UnsafeTarget(f"address {ip} is not a public internet address")


async def resolve_public(host: str, port: int) -> list[str]:
    literal, _ = parse_ip_host(host)
    if literal is not None:
        ensure_public(literal)
        return [str(literal)]
    loop = asyncio.get_running_loop()
    try:
        infos = await loop.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise UnsafeTarget("host did not resolve") from exc
    addresses: list[str] = []
    for _fam, _t, _p, _c, sockaddr in infos:
        ip = ipaddress.ip_address(sockaddr[0].split("%", 1)[0])
        ensure_public(ip)  # reject if ANY answer is internal
        if str(ip) not in addresses:
            addresses.append(str(ip))
    if not addresses:
        raise UnsafeTarget("host did not resolve")
    return addresses


@dataclass
class Expansion:
    final_url: str | None = None
    chain: list[str] = field(default_factory=list)
    error: str | None = None


async def expand(url: str, *, timeout: float = 4.0, max_hops: int = 5, resolver: Resolver = resolve_public,
                 transport: httpx.AsyncBaseTransport | None = None) -> Expansion:
    result = Expansion(chain=[url])
    current = url
    try:
        async with asyncio.timeout(timeout * 2):
            async with httpx.AsyncClient(follow_redirects=False, timeout=timeout, transport=transport, verify=True,
                                         headers={"User-Agent": "LinkLens-Expander/1.0", "Accept": "*/*"}) as client:
                for _ in range(max_hops):
                    parts = urlsplit(current)
                    if parts.scheme not in {"http", "https"} or not parts.hostname:
                        raise UnsafeTarget("only http(s) links are expanded")
                    port = parts.port
                    if port not in _ALLOWED_PORTS:
                        raise UnsafeTarget(f"port {port} is not allowed")
                    default_port = 443 if parts.scheme == "https" else 80
                    host = parts.hostname
                    ip = (await resolver(host, port or default_port))[0]

                    ip_netloc = f"[{ip}]" if ":" in ip else ip
                    pinned = parts._replace(netloc=f"{ip_netloc}:{port}" if port else ip_netloc).geturl()
                    headers = {"Host": f"{host}:{port}" if port else host}
                    extensions = {"sni_hostname": host} if parts.scheme == "https" else {}

                    async with client.stream("GET", pinned, headers=headers, extensions=extensions) as resp:
                        status, location = resp.status_code, resp.headers.get("location")
                    if status in _REDIRECT_CODES and location:
                        current = urljoin(current, location)
                        result.chain.append(current)
                        continue
                    break
                else:
                    result.error = "too many redirects"
        result.final_url = current
    except UnsafeTarget as exc:
        result.error = f"blocked for safety: {exc}"
    except (httpx.HTTPError, TimeoutError, OSError) as exc:
        result.error = f"could not follow the link ({type(exc).__name__})"
    return result
