"""Social-engineering analysis of the pasted message text."""
from __future__ import annotations

import re

from .. import data_loader
from ..models import Signal
from ..utils import shorten
from .homoglyph import scripts_in
from .url_analyzer import mk

# "Never share your OTP" is advice, not a request. Look a short distance back for a negation.
_NEGATION = re.compile(
    r"(?:\b(?:do not|don'?t|dont|never|not|won'?t|will never|should not|shouldn'?t|avoid|beware)\b|"
    r"\b(?:bank|we|company|team|staff|employees?) (?:will never|never|do not|don'?t) (?:ask|request|call))",
    re.IGNORECASE,
)
_WORD = re.compile(r"\w{3,}", re.UNICODE)


def _negated(text: str, start: int) -> bool:
    window = text[max(0, start - 45): start]
    return bool(_NEGATION.search(window))


def analyze_text(text: str) -> list[Signal]:
    signals: list[Signal] = []
    cats = data_loader.text_patterns()

    for cid, cfg in cats.items():
        matches: list[str] = []
        for pattern in cfg["patterns"]:
            for m in pattern.finditer(text):
                if cfg["negatable"] and _negated(text, m.start()):
                    continue
                phrase = m.group(0).strip().lower()
                if phrase not in matches:
                    matches.append(phrase)
                if len(matches) >= 6:
                    break
            if len(matches) >= 6:
                break
        if not matches:
            continue
        # More distinct phrases in one category => stronger, with diminishing returns.
        weight = min(0.9, cfg["weight"] * (1 + 0.35 * (len(matches) - 1)))
        signals.append(mk(f"text_{cid}", f"text:{cid}", cfg["title"],
                          "Matched wording commonly used in phishing and scam messages.",
                          weight, evidence="; ".join(shorten(m, 50) for m in matches[:4])))

    # Words that mix alphabets (e.g. a Cyrillic 'а' inside 'Pаypal') to slip past keyword filters.
    mixed: list[str] = []
    for m in _WORD.finditer(text[:20_000]):
        word = m.group(0)
        if word.isascii():
            continue
        scripts = scripts_in(word)
        scripts.discard("OTHER")
        if len(scripts) > 1 and "LATIN" in scripts:
            mixed.append(word)
            if len(mixed) >= 3:
                break
    if mixed:
        signals.append(mk("text_mixed_script", "text:obfuscation", "Words that mix alphabets",
                          "Letters from other alphabets are swapped in to evade spam filters and imitate brand names.",
                          0.4, evidence=", ".join(mixed)))

    letters = [c for c in text if c.isalpha()]
    if len(letters) >= 30:
        caps = sum(c.isupper() for c in letters) / len(letters)
        if caps > 0.55 or text.count("!") >= 4:
            signals.append(mk("text_shouting", "text:tone", "Shouting / excessive emphasis",
                              "Heavy capitals or exclamation marks are used to create panic.", 0.06))
    return signals
