"""Reputation sources. The offline blocklist is always available; the rest are opt-in network lookups.

Design rule: a failing or missing source must never break the analysis and must never be silently
treated as "clean". Failures are reported to the user in the `checks` list.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import httpx

from ..utils import TTLCache

_DOMAIN_RE = re.compile(r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")


def _norm_url(url: str) -> str:
    url = url.strip().lower().split("#", 1)[0]
    url = re.sub(r"^[a-z][a-z0-9+.-]*://", "", url)
    return url.rstrip("/")


class Blocklist:
    """Flat-file blocklist. One entry per line: a domain (blocks subdomains too) or a full URL. '#' = comment."""

    def __init__(self, domains: set[str], urls: set[str], source: str | None) -> None:
        self.domains = domains
        self.urls = urls
        self.source = source

    @classmethod
    def load(cls, path: str | None) -> "Blocklist":
        candidate = Path(path) if path else Path(__file__).parent.parent / "data" / "blocklist.txt"
        domains: set[str] = set()
        urls: set[str] = set()
        if candidate.is_file():
            for line in candidate.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.split("#", 1)[0].strip()
                if not line:
                    continue
                norm = _norm_url(line)
                (urls if "/" in norm else domains).add(norm)
        return cls(domains, urls, str(candidate) if candidate.is_file() else None)

    def __len__(self) -> int:
        return len(self.domains) + len(self.urls)

    def match(self, host: str | None, normalized_url: str | None) -> str | None:
        if normalized_url and _norm_url(normalized_url) in self.urls:
            return "exact URL"
        if host:
            parts = host.lower().split(".")
            for i in range(len(parts) - 1):
                if ".".join(parts[i:]) in self.domains:
                    return "domain"
        return None


async def domain_age_days(client: httpx.AsyncClient, domain: str, cache: TTLCache) -> int | None:
    """Days since registration via RDAP (the modern, structured WHOIS replacement). None if unknown."""
    domain = domain.lower().strip(".")
    if not _DOMAIN_RE.match(domain):  # ASCII/punycode only; also guarantees nothing odd reaches the URL path
        return None
    cached = cache.get(domain)
    if cached is not None:
        return None if cached == -1 else cached
    resp = await client.get(f"https://rdap.org/domain/{domain}", follow_redirects=True,
                            headers={"Accept": "application/rdap+json"})
    if resp.status_code == 404:
        cache.set(domain, -1)
        return None
    resp.raise_for_status()
    for event in resp.json().get("events", []):
        if event.get("eventAction") == "registration" and event.get("eventDate"):
            registered = datetime.fromisoformat(event["eventDate"].replace("Z", "+00:00"))
            if registered.tzinfo is None:
                registered = registered.replace(tzinfo=timezone.utc)
            age = max(0, (datetime.now(timezone.utc) - registered).days)
            cache.set(domain, age)
            return age
    cache.set(domain, -1)
    return None


async def safe_browsing_lookup(client: httpx.AsyncClient, api_key: str, urls: list[str]) -> dict[str, str]:
    """Google Safe Browsing v4 Lookup API. Returns {url: threat_type}.

    NOTE: Google restricts this API to non-commercial use and the submitted URLs are sent to Google.
    """
    if not urls:
        return {}
    body = {
        "client": {"clientId": "linklens", "clientVersion": "1.0"},
        "threatInfo": {
            "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
            "platformTypes": ["ANY_PLATFORM"],
            "threatEntryTypes": ["URL"],
            "threatEntries": [{"url": u} for u in urls[:50]],
        },
    }
    resp = await client.post("https://safebrowsing.googleapis.com/v4/threatMatches:find",
                             params={"key": api_key}, json=body)
    resp.raise_for_status()
    out: dict[str, str] = {}
    for match in resp.json().get("matches", []):
        out[match.get("threat", {}).get("url", "")] = match.get("threatType", "UNKNOWN")
    return out


def host_of(url: str) -> str | None:
    try:
        return urlsplit(url if "//" in url else "//" + url).hostname
    except ValueError:
        return None
