"""Orchestrates extraction, analysis, optional lookups and final scoring."""
from __future__ import annotations

import asyncio
import re
import time

import httpx

from . import __version__
from .analyzers import redirects, reputation
from .analyzers.extract import ExtractedLink, extract_links, strip_invisible
from .analyzers.text_analyzer import analyze_text
from .analyzers.url_analyzer import UrlAnalyzer, UrlFacts, mk
from .config import Settings
from .models import AnalyzeResponse, Check, LinkResult, Signal, TextResult
from .scoring import VERDICTS, combine, confidence_for, level_for, to_score
from .utils import TTLCache, defang

_URLISH = re.compile(r"(?i)\b(?:https?|ftp)://\S+|\bwww\.\S+|\b(?:[\w-]{1,63}\.){1,12}[a-z]{2,24}(?:/\S*)?")


class Engine:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.urls = UrlAnalyzer()
        self.blocklist = reputation.Blocklist.load(settings.blocklist_path)
        self._rdap_cache: TTLCache[int] = TTLCache(maxsize=2048, ttl=6 * 3600)
        self._client: httpx.AsyncClient | None = None

    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.settings.network_timeout,
                                             headers={"User-Agent": "LinkLens/1.0"})
        return self._client

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()

    # ------------------------------------------------------------------ main
    async def analyze(self, text: str, expand_redirects: bool = False) -> AnalyzeResponse:
        t0 = time.perf_counter()
        cfg = self.settings
        truncated = len(text) > cfg.max_text_chars
        text = text[: cfg.max_text_chars]
        clean, _ = strip_invisible(text)

        links: list[ExtractedLink] = extract_links(clean)
        if not links:
            words = clean.split()
            if len(words) == 1 and ("." in words[0] or ":" in words[0]):
                links = [ExtractedLink(words[0])]
        links_truncated = len(links) > cfg.max_links
        links = links[: cfg.max_links]

        facts: list[UrlFacts] = [self.urls.analyze(l.url, l.anchor_text) for l in links]
        # Hidden characters are removed from `clean`, so report them once for the whole message.
        checks: list[Check] = [Check(name="Built-in heuristics", status="ok",
                                     note="URL structure, look-alike domains, social-engineering wording (works on brand-new, unlisted links).")]
        notes: list[str] = []

        # ---- offline blocklist
        if len(self.blocklist):
            checks.append(Check(name="Local blocklist", status="ok", note=f"{len(self.blocklist):,} entries checked."))
            for f in facts:
                hit = self.blocklist.match(f.host, f.normalized)
                if hit:
                    f.signals.append(mk("blocklist_hit", "reputation", "Listed in the local blocklist",
                                        f"Matched a known-bad {hit}.", 0.97, evidence=f.host))
        else:
            checks.append(Check(name="Local blocklist", status="skipped", note="No blocklist file loaded (optional)."))

        # ---- optional network lookups
        if cfg.enable_network_lookups:
            await self._network_lookups(facts, checks)
        else:
            checks.append(Check(name="Domain age (RDAP)", status="skipped", note="Network lookups are disabled on this server."))
            checks.append(Check(name="Google Safe Browsing", status="skipped", note="Network lookups are disabled on this server."))

        # ---- optional, guarded redirect expansion
        expansions: dict[int, redirects.Expansion] = {}
        if expand_redirects and cfg.enable_redirect_expansion:
            targets = [i for i, f in enumerate(facts) if f.is_shortener][:3]
            results = await asyncio.gather(*(redirects.expand(facts[i].normalized or facts[i].original,
                                                                timeout=cfg.network_timeout) for i in targets))
            for i, res in zip(targets, results):
                expansions[i] = res
            if targets:
                failed = [r for r in results if r.error]
                checks.append(Check(name="Redirect expansion", status="failed" if failed and len(failed) == len(results) else "ok",
                                    note=f"Followed {len(targets)} short link(s) with SSRF protection."
                                         + (f" {failed[0].error}." if failed else "")))
        elif expand_redirects:
            checks.append(Check(name="Redirect expansion", status="skipped", note="Disabled on this server (it is opt-in for safety)."))

        # ---- build per-link results
        link_results: list[LinkResult] = []
        for i, f in enumerate(facts):
            signals = list(f.signals)
            exp = expansions.get(i)
            expanded_to = None
            chain: list[str] = []
            if exp and exp.final_url and not exp.error:
                expanded_to, chain = exp.final_url, exp.chain
                dest = self.urls.analyze(exp.final_url)
                for s in dest.signals:
                    if s.weight > 0:
                        signals.append(s.model_copy(update={
                            "id": f"dest_{s.id}", "title": f"Destination: {s.title}",
                            "detail": s.detail, "evidence": s.evidence or dest.host}))
            elif exp and exp.error:
                signals.append(mk("expand_failed", "obfuscation", "Short link could not be safely expanded",
                                  exp.error[:140], 0.08))
            p = combine(signals)
            score = to_score(p)
            link_results.append(LinkResult(
                original=f.original[:2000], defanged=defang(f.original[:2000]), normalized=f.normalized,
                host=f.host, registered_domain=f.registered_domain, score=score, level=level_for(score),
                signals=sorted(signals, key=lambda s: s.weight, reverse=True), expanded_to=expanded_to,
                redirect_chain=chain))

        # ---- text
        prose = _URLISH.sub(" ", clean)
        text_result: TextResult | None = None
        text_signals: list[Signal] = []
        if len(prose.split()) >= 3:
            text_signals = analyze_text(clean)
            tscore = to_score(combine(text_signals))
            text_result = TextResult(score=tscore, level=level_for(tscore),
                                     signals=sorted(text_signals, key=lambda s: s.weight, reverse=True))

        # ---- overall
        link_p = max((combine(r.signals) for r in link_results), default=0.0)
        text_p = combine(text_signals)
        combo: list[Signal] = []
        n_text_cats = len({s.category for s in text_signals if s.weight >= 0.1})
        if n_text_cats >= 2 and any(r.score >= 25 for r in link_results):
            combo.append(mk("combo_pressure_plus_link", "combo", "Pressure tactics plus a suspicious link",
                            "The wording tries to rush you and the link has red flags of its own. Together they are a typical phishing pattern.", 0.25))
        all_signals = [s for r in link_results for s in r.signals] + text_signals + combo
        survive = (1 - link_p) * (1 - text_p)
        for s in combo:
            survive *= 1 - s.weight
        overall_p = 1 - survive
        # a hard reputation hit on any link must dominate
        for r in link_results:
            if any(s.category == "reputation" and s.weight >= 0.9 for s in r.signals):
                overall_p = max(overall_p, combine(r.signals))
        score = to_score(overall_p)
        level = level_for(score)

        if truncated:
            notes.append(f"Only the first {cfg.max_text_chars:,} characters were analysed.")
        if links_truncated:
            notes.append(f"Only the first {cfg.max_links} links were analysed.")
        if not links and text_result is None:
            notes.append("Nothing recognisable as a link or a message was found. Paste the full message or a link.")

        scored = [s for s in all_signals if s.weight > 0]
        scored.sort(key=lambda s: s.weight, reverse=True)
        top, seen = [], set()
        for s in scored:
            key = s.id.replace("dest_", "")
            if key in seen:
                continue
            seen.add(key)
            top.append(s.title if not s.evidence else f"{s.title} ({s.evidence})")
            if len(top) == 4:
                break

        resp = AnalyzeResponse(
            score=score, level=level, verdict=VERDICTS[level], confidence=confidence_for(all_signals, score),  # type: ignore[arg-type]
            summary=self._summary(level, len(link_results), text_result is not None, top),
            recommendations=self._recommendations(level, link_results, text_signals),
            top_reasons=top, text_analysis=text_result, links=link_results, checks=checks, notes=notes,
            meta={"version": __version__, "elapsed_ms": round((time.perf_counter() - t0) * 1000, 1),
                  "links_found": len(link_results), "chars": len(text), "truncated": truncated})
        return resp

    # ------------------------------------------------------------------ optional network checks
    async def _network_lookups(self, facts: list[UrlFacts], checks: list[Check]) -> None:
        client = self._http()
        by_domain: dict[str, list[UrlFacts]] = {}
        for f in facts:
            if f.registered_domain and f.legit_brand is None and "." in f.registered_domain and not f.registered_domain[0].isdigit():
                by_domain.setdefault(f.registered_domain, []).append(f)
        domains = list(by_domain)[:8]

        if domains:
            results = await asyncio.gather(*(reputation.domain_age_days(client, d, self._rdap_cache) for d in domains),
                                           return_exceptions=True)
            errors = sum(isinstance(r, Exception) for r in results)
            for d, age in zip(domains, results):
                if isinstance(age, Exception) or age is None:
                    continue
                w, label = (0.5, "less than 3 days") if age < 3 else (0.42, "less than 2 weeks") if age < 14 else \
                           (0.32, "less than a month") if age < 30 else (0.16, "less than 3 months") if age < 90 else (0.0, "")
                if w:
                    sig = mk("young_domain", "domain_age", f"Domain registered very recently ({age} days ago)",
                             f"Registered {label} ago. Phishing domains are typically used within days of registration. "
                             "New domains can also be legitimate.", w, evidence=d)
                    for f in by_domain[d]:
                        f.signals.append(sig)
            checks.append(Check(name="Domain age (RDAP)", status="failed" if errors == len(domains) else "ok",
                                note=f"Looked up {len(domains) - errors} of {len(domains)} domain(s)."
                                     + (" Some lookups failed; absence of a warning is not a clean result." if errors else "")))
        else:
            checks.append(Check(name="Domain age (RDAP)", status="skipped", note="No unknown domains to look up."))

        if self.settings.gsb_api_key:
            urls = [f.normalized for f in facts if f.normalized]
            try:
                matches = await reputation.safe_browsing_lookup(client, self.settings.gsb_api_key, urls)
                for f in facts:
                    threat = matches.get(f.normalized or "")
                    if threat:
                        f.signals.append(mk("gsb_hit", "reputation", "Flagged by Google Safe Browsing",
                                            f"Google lists this address as {threat.replace('_', ' ').lower()}.", 0.97))
                checks.append(Check(name="Google Safe Browsing", status="ok", note=f"Checked {len(urls)} URL(s). A miss does not mean the link is safe."))
            except (httpx.HTTPError, ValueError) as exc:
                checks.append(Check(name="Google Safe Browsing", status="failed", note=f"Lookup failed ({type(exc).__name__})."))
        else:
            checks.append(Check(name="Google Safe Browsing", status="skipped", note="No API key configured."))

    # ------------------------------------------------------------------ wording
    @staticmethod
    def _summary(level: str, n_links: int, has_text: bool, top: list[str]) -> str:
        what = "message and its links" if has_text and n_links else "link" if n_links == 1 else "links" if n_links else "message"
        if level == "low":
            return (f"No strong phishing indicators were found in this {what}. That is not a guarantee: brand-new "
                    "phishing pages often look clean, so be careful with anything that asks you to log in or pay.")
        lead = {"medium": "Some warning signs were found", "high": "Several strong phishing indicators were found",
                "critical": "Multiple independent red flags were found"}[level]
        return f"{lead} in this {what}: " + "; ".join(t.rstrip(".") for t in top[:3]) + "."

    @staticmethod
    def _recommendations(level: str, links: list[LinkResult], text_signals: list[Signal]) -> list[str]:
        recs: list[str] = []
        ids = {s.id for r in links for s in r.signals} | {s.id for s in text_signals}
        if level in {"high", "critical"}:
            recs += ["Do not click the link, open attachments, scan QR codes or reply.",
                     "Do not share passwords, OTPs, PINs or card details, whoever claims to be asking."]
        elif level == "medium":
            recs.append("Do not log in or pay through this link. Confirm with the sender through a channel you already trust.")
        else:
            recs.append("Low risk is not proof of safety. Prefer opening the official app or typing the address yourself for logins and payments.")
        if "text_credentials" in ids:
            recs.append("Real banks and services never ask for your OTP, PIN or password by message or call.")
        if "shortener" in ids:
            recs.append("Ask the sender for the full address, or expand the short link with a trusted tool before opening it.")
        if ids & {"brand_lookalike", "brand_typosquat", "brand_in_subdomain", "brand_combosquat", "brand_other_tld", "mixed_script", "userinfo_trick"}:
            recs.append("Go to the organisation’s official site by typing its address or using its app, not this link.")
        if level in {"high", "critical"}:
            recs.append("If you already entered details: change that password everywhere you reuse it, enable 2-factor "
                        "authentication, and contact your bank or provider at once. In India, call 1930 or report at cybercrime.gov.in.")
        return recs
