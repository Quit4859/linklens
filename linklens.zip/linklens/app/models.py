"""Pydantic models shared by the API and the analyzers."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

Level = Literal["low", "medium", "high", "critical"]
Severity = Literal["info", "low", "medium", "high"]


class Signal(BaseModel):
    """One piece of evidence. Every score is explained by a list of these."""

    id: str
    category: str
    title: str
    detail: str
    weight: float = Field(ge=0.0, le=1.0, description="Probability-like strength of the evidence")
    severity: Severity = "low"
    evidence: str | None = None


class Check(BaseModel):
    """Transparency record: which optional checks ran, and which were skipped."""

    name: str
    status: Literal["ok", "skipped", "failed"]
    note: str


class LinkResult(BaseModel):
    original: str
    defanged: str
    normalized: str | None = None
    host: str | None = None
    registered_domain: str | None = None
    score: int
    level: Level
    signals: list[Signal]
    expanded_to: str | None = None
    redirect_chain: list[str] = []


class TextResult(BaseModel):
    score: int
    level: Level
    signals: list[Signal]


class AnalyzeRequest(BaseModel):
    text: str = Field(min_length=1, max_length=200_000)
    expand_redirects: bool = False


class AnalyzeResponse(BaseModel):
    score: int
    level: Level
    verdict: str
    confidence: Literal["low", "medium", "high"]
    summary: str
    recommendations: list[str]
    top_reasons: list[str]
    text_analysis: TextResult | None
    links: list[LinkResult]
    checks: list[Check]
    notes: list[str]
    meta: dict
