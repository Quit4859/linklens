"""Runtime configuration, read once from environment variables."""
from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    # Input limits (protect the server and keep regex work bounded)
    max_text_chars: int
    max_links: int
    max_body_bytes: int

    # Abuse protection
    rate_limit_per_minute: int
    trusted_proxy_hops: int

    # Optional network features (all OFF by default; the core engine is fully offline)
    enable_network_lookups: bool  # RDAP domain age (+ Safe Browsing if a key is set)
    enable_redirect_expansion: bool  # SSRF-guarded expansion of URL shorteners
    gsb_api_key: str | None
    network_timeout: float

    # Misc
    enable_docs: bool
    allowed_origins: tuple[str, ...]
    blocklist_path: str | None


@lru_cache
def get_settings() -> Settings:
    origins = tuple(o.strip() for o in os.getenv("ALLOWED_ORIGINS", "").split(",") if o.strip())
    return Settings(
        max_text_chars=_env_int("MAX_TEXT_CHARS", 20_000),
        max_links=_env_int("MAX_LINKS", 25),
        max_body_bytes=_env_int("MAX_BODY_BYTES", 120_000),
        rate_limit_per_minute=_env_int("RATE_LIMIT_PER_MINUTE", 30),
        trusted_proxy_hops=_env_int("TRUSTED_PROXY_HOPS", 1),
        enable_network_lookups=_env_bool("ENABLE_NETWORK_LOOKUPS", False),
        enable_redirect_expansion=_env_bool("ENABLE_REDIRECT_EXPANSION", False),
        gsb_api_key=os.getenv("GOOGLE_SAFE_BROWSING_KEY") or None,
        network_timeout=_env_float("NETWORK_TIMEOUT", 4.0),
        enable_docs=_env_bool("ENABLE_DOCS", False),
        allowed_origins=origins,
        blocklist_path=os.getenv("BLOCKLIST_PATH") or None,
    )
