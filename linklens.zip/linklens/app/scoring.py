"""Explainable scoring.

Why not just add weights together (what many checkers do)?
  * Signals are correlated. "login" in the domain, "verify" in the path and a risky TLD often come from the
    same cheap phishing kit. Simple addition double-counts them and inflates scores.
  * Instead each signal is a probability-like strength. Inside one category we apply diminishing returns
    (each extra signal counts for half as much), then combine *independent* categories with a noisy-OR:
        P(risk) = 1 - prod(1 - p_category)
    Independent kinds of evidence reinforce each other; piles of the same kind do not.
"""
from __future__ import annotations

from .models import Level, Signal

CATEGORY_CAP = 0.92
WITHIN_CATEGORY_DISCOUNT = 0.5


def category_probability(weights: list[float]) -> float:
    ordered = sorted((w for w in weights if w > 0), reverse=True)
    survive = 1.0
    for i, w in enumerate(ordered):
        survive *= 1.0 - w * (WITHIN_CATEGORY_DISCOUNT ** i)
    return min(CATEGORY_CAP, 1.0 - survive)


def combine(signals: list[Signal]) -> float:
    """Return a 0..1 risk probability from a list of signals."""
    by_cat: dict[str, list[float]] = {}
    hard_floor = 0.0
    for s in signals:
        by_cat.setdefault(s.category, []).append(s.weight)
        if s.category == "reputation" and s.weight >= 0.9:
            hard_floor = max(hard_floor, s.weight)
    survive = 1.0
    for ws in by_cat.values():
        survive *= 1.0 - category_probability(ws)
    p = 1.0 - survive
    return max(p, hard_floor)


def to_score(p: float) -> int:
    return max(0, min(100, round(p * 100)))


def level_for(score: int) -> Level:
    if score >= 75:
        return "critical"
    if score >= 50:
        return "high"
    if score >= 25:
        return "medium"
    return "low"


VERDICTS: dict[str, str] = {
    "low": "No strong phishing indicators found",
    "medium": "Some suspicious signs — be careful",
    "high": "Likely phishing or a scam",
    "critical": "Very likely phishing or a scam",
}


def confidence_for(signals: list[Signal], score: int) -> str:
    cats = {s.category.split(":")[0] for s in signals if s.weight >= 0.1}
    hit = any(s.category == "reputation" and s.weight >= 0.9 for s in signals)
    if hit or len(cats) >= 4:
        return "high"
    if len(cats) >= 2:
        return "medium"
    return "low"
