"""Loads the JSON knowledge files once. Edit app/data/*.json to extend the rules without touching code."""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"


def _load(name: str):
    with (DATA_DIR / name).open(encoding="utf-8") as fh:
        return json.load(fh)


@lru_cache
def brands() -> list[dict]:
    return _load("brands.json")


@lru_cache
def lists() -> dict:
    return _load("lists.json")


@lru_cache
def text_patterns() -> dict:
    """Compile every pattern once at start-up."""
    raw = _load("text_patterns.json")
    compiled: dict[str, dict] = {}
    for cid, cfg in raw.items():
        compiled[cid] = {
            "title": cfg["title"],
            "weight": float(cfg["weight"]),
            "negatable": bool(cfg.get("negatable", False)),
            "patterns": [re.compile(p, re.IGNORECASE) for p in cfg["patterns"]],
        }
    return compiled
