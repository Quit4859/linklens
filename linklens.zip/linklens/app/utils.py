"""Small shared helpers: TTL cache, defanging and text normalisation."""
from __future__ import annotations

import re
import time
from collections import OrderedDict
from typing import Generic, TypeVar

T = TypeVar("T")


class TTLCache(Generic[T]):
    """Tiny size-bounded TTL cache (single process, event-loop safe)."""

    def __init__(self, maxsize: int = 1024, ttl: float = 3600.0) -> None:
        self._data: OrderedDict[str, tuple[float, T]] = OrderedDict()
        self._maxsize = maxsize
        self._ttl = ttl

    def get(self, key: str) -> T | None:
        item = self._data.get(key)
        if item is None:
            return None
        expires, value = item
        if expires < time.monotonic():
            self._data.pop(key, None)
            return None
        self._data.move_to_end(key)
        return value

    def set(self, key: str, value: T) -> None:
        self._data[key] = (time.monotonic() + self._ttl, value)
        self._data.move_to_end(key)
        while len(self._data) > self._maxsize:
            self._data.popitem(last=False)


_DEFANG_SCHEME = re.compile(r"^(h)(t)(t)(p)(s?)(:)", re.IGNORECASE)


def defang(url: str) -> str:
    """Make a URL non-clickable so it is safe to display and copy around."""
    out = _DEFANG_SCHEME.sub(lambda m: "hxxp" + m.group(5) + ":", url)
    return out.replace(".", "[.]")


def shorten(text: str, limit: int = 120) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 1] + "…"
