"""FastAPI application: JSON API plus the static front-end."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import __version__
from .config import get_settings
from .engine import Engine
from .models import AnalyzeRequest, AnalyzeResponse
from .ratelimit import RateLimiter, client_ip

# Privacy: we never log submitted text or URLs, only counts and errors.
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("linklens")

STATIC_DIR = Path(__file__).parent / "static"
settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.engine = Engine(settings)
    app.state.limiter = RateLimiter(settings.rate_limit_per_minute)
    log.info("LinkLens %s started (network_lookups=%s, redirect_expansion=%s)", __version__,
             settings.enable_network_lookups, settings.enable_redirect_expansion)
    yield
    await app.state.engine.aclose()


app = FastAPI(
    title="LinkLens",
    version=__version__,
    description="Explainable phishing-risk analysis for links and messages.",
    lifespan=lifespan,
    docs_url="/docs" if settings.enable_docs else None,
    redoc_url=None,
)

if settings.allowed_origins:
    app.add_middleware(CORSMiddleware, allow_origins=list(settings.allowed_origins),
                       allow_methods=["GET", "POST"], allow_headers=["Content-Type"], allow_credentials=False)

_CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; "
        "base-uri 'none'; form-action 'none'; frame-ancestors 'none'; object-src 'none'")


@app.middleware("http")
async def harden(request: Request, call_next):
    length = request.headers.get("content-length")
    if length and length.isdigit() and int(length) > settings.max_body_bytes:
        return JSONResponse({"detail": "Request too large."}, status_code=413)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if not request.url.path.startswith("/docs") and not request.url.path.startswith("/openapi"):
        response.headers["Content-Security-Policy"] = _CSP
        response.headers["X-Frame-Options"] = "DENY"
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    return response


@app.post("/api/analyze", response_model=AnalyzeResponse)
async def analyze(payload: AnalyzeRequest, request: Request):
    ip = client_ip(request, settings.trusted_proxy_hops)
    allowed, retry_after = request.app.state.limiter.allow(ip)
    if not allowed:
        return JSONResponse({"detail": "Too many requests. Please wait a moment and try again."},
                            status_code=429, headers={"Retry-After": str(retry_after)})
    result = await request.app.state.engine.analyze(payload.text, payload.expand_redirects)
    log.info("analyzed chars=%d links=%d score=%d", len(payload.text), result.meta["links_found"], result.score)
    return result


@app.api_route("/api/health", methods=["GET", "HEAD"])
async def health():
    return {
        "status": "ok",
        "version": __version__,
        "features": {
            "network_lookups": settings.enable_network_lookups,
            "safe_browsing": bool(settings.gsb_api_key) and settings.enable_network_lookups,
            "redirect_expansion": settings.enable_redirect_expansion,
        },
    }


@app.api_route("/", methods=["GET", "HEAD"], include_in_schema=False)
async def index():
    return FileResponse(STATIC_DIR / "index.html")


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
