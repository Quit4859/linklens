/* LinkLens front-end. No dependencies, no build step.
 * SECURITY: everything that comes from the server (which echoes attacker-controlled text) is inserted with
 * textContent / createTextNode only, never innerHTML, so a malicious paste cannot inject markup or script. */
(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const input = $("input"), go = $("go"), clear = $("clear"), counter = $("counter");
  const status = $("status"), result = $("result"), expandWrap = $("expand-wrap"), expand = $("expand");
  const MAX = Number(input.getAttribute("maxlength")) || 20000;

  const EXAMPLES = {
    sms: "URGENT: Your SBI account has been suspended. Complete your KYC within 24 hours or it will be blocked: http://sbi-kyc-update.xyz/login . Enter your OTP to verify.",
    lookalike: "https://paypa1.com/signin/verify",
    mismatch: 'Dear customer, your parcel is on hold. Please <a href="http://track-parcel.top/pay">www.amazon.in/track</a> and pay the delivery fee.',
    legit: "Your OTP is 482913. Do not share it with anyone. Never share your OTP, PIN or CVV. - HDFC Bank",
  };

  const LEVEL_TEXT = { low: "Low risk", medium: "Medium risk", high: "High risk", critical: "Critical risk" };
  const SEV_TEXT = { info: "Info", low: "Minor", medium: "Notable", high: "Strong" };
  const SEV_CLASS = { info: "lvl-info", low: "lvl-low", medium: "lvl-medium", high: "lvl-high" };
  const SVG_NS = "http://www.w3.org/2000/svg";

  /** Tiny DOM helper: h("div", {class: "x"}, "text", childNode) */
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === false || v == null) continue;
      el.setAttribute(k, v === true ? "" : v);
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      el.appendChild(typeof kid === "string" ? document.createTextNode(kid) : kid);
    }
    return el;
  }

  function gauge(score, level) {
    const r = 52, c = 2 * Math.PI * r;
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("viewBox", "0 0 124 124");
    svg.setAttribute("aria-hidden", "true");
    const mk = (cls, offset) => {
      const circle = document.createElementNS(SVG_NS, "circle");
      circle.setAttribute("class", cls);
      circle.setAttribute("cx", "62"); circle.setAttribute("cy", "62"); circle.setAttribute("r", String(r));
      circle.setAttribute("fill", "none"); circle.setAttribute("stroke-width", "11"); circle.setAttribute("stroke-linecap", "round");
      circle.setAttribute("stroke-dasharray", String(c));
      circle.setAttribute("stroke-dashoffset", String(offset));
      return circle;
    };
    const track = mk("track", 0);
    const bar = mk("bar", c);
    svg.append(track, bar);
    requestAnimationFrame(() => requestAnimationFrame(() => bar.setAttribute("stroke-dashoffset", String(c * (1 - Math.max(score, 2) / 100)))));
    return h("div", { class: `gauge lvl-${level}` }, svg,
      h("div", { class: "num" }, h("div", {}, h("b", {}, String(score)), h("small", {}, "out of 100"))));
  }

  function signalRow(s) {
    const cls = SEV_CLASS[s.severity] || "lvl-info";
    return h("div", { class: `sig ${cls}` },
      h("div", { class: "sev" }, SEV_TEXT[s.severity] || "Info"),
      h("div", {},
        h("div", { class: "t" }, s.title),
        h("div", { class: "d" }, s.detail),
        s.evidence ? h("code", {}, s.evidence) : null));
  }

  function signalList(signals, emptyText) {
    if (!signals.length) return h("div", { class: "empty" }, emptyText);
    return h("div", {}, signals.map(signalRow));
  }

  function linkCard(link, openByDefault) {
    const warn = link.signals.filter((s) => s.weight > 0);
    const good = link.signals.filter((s) => s.weight === 0);
    return h("details", { class: `link-card lvl-${link.level}`, open: openByDefault },
      h("summary", {},
        h("span", { class: "pill" }, String(link.score)),
        h("span", { class: "url" }, link.defanged),
        h("span", { class: "badge" }, LEVEL_TEXT[link.level].replace(" risk", ""))),
      h("div", { class: "link-body" },
        link.registered_domain ? h("p", { class: "kv" }, "Real domain: ", h("code", {}, link.registered_domain.replace(/\./g, "[.]"))) : null,
        link.expanded_to ? h("p", { class: "kv" }, "Leads to: ", h("code", {}, link.expanded_to.replace(/^http/i, "hxxp").replace(/\./g, "[.]"))) : null,
        signalList(warn, "No warning signs were found in the link itself."),
        good.length ? h("div", {}, good.map(signalRow)) : null));
  }

  function reportText(r) {
    const lines = [`LinkLens report: ${r.score}/100 (${LEVEL_TEXT[r.level]}) - ${r.verdict}`, "", r.summary, ""];
    if (r.top_reasons.length) { lines.push("Why:"); r.top_reasons.forEach((t) => lines.push(`- ${t}`)); lines.push(""); }
    r.links.forEach((l) => lines.push(`Link ${l.defanged} -> ${l.score}/100`));
    lines.push("", "Heuristic result, not a guarantee.");
    return lines.join("\n");
  }

  function render(r) {
    const hero = h("div", { class: `card hero lvl-${r.level}` },
      gauge(r.score, r.level),
      h("div", {},
        h("span", { class: "badge" }, LEVEL_TEXT[r.level]),
        h("h2", {}, r.verdict),
        h("p", {}, r.summary),
        h("p", { class: "conf" }, `Evidence strength: ${r.confidence}. `,
          r.level === "low" ? "No findings here is not proof that it is safe." : "")));

    const nodes = [hero];

    nodes.push(h("section", { class: "card sec todo" }, h("h2", {}, "What to do"),
      h("ul", {}, r.recommendations.map((t) => h("li", {}, t)))));

    if (r.links.length) {
      nodes.push(h("section", { class: "card sec" },
        h("h2", {}, `Links found (${r.links.length})`),
        h("p", { class: "muted small", style: false }, "Shown disarmed so they cannot be clicked by accident. Tap one for details."),
        r.links.map((l, i) => linkCard(l, i === 0 && r.links.length <= 3 && l.score >= 25))));
    }

    if (r.text_analysis) {
      nodes.push(h("section", { class: "card sec" },
        h("h2", {}, `Message wording (${r.text_analysis.score}/100)`),
        signalList(r.text_analysis.signals, "No common scam wording was found in the message text.")));
    }

    nodes.push(h("section", { class: "card sec" }, h("h2", {}, "What was checked"),
      h("ul", { class: "checks" }, r.checks.map((c) =>
        h("li", {}, h("span", { class: `st st-${c.status}` }, c.status), h("span", {}, h("b", {}, c.name + ": "), c.note))))));

    (r.notes || []).forEach((n) => nodes.push(h("div", { class: "note" }, n)));

    const copy = h("button", { class: "btn", type: "button" }, "Copy report");
    copy.addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(reportText(r)); copy.textContent = "Copied"; }
      catch { copy.textContent = "Copy failed"; }
      setTimeout(() => (copy.textContent = "Copy report"), 1800);
    });
    nodes.push(h("div", { class: "tools" }, copy, h("span", { class: "muted small" }, `Analysed in ${r.meta.elapsed_ms} ms`)));

    result.replaceChildren(...nodes);
    result.hidden = false;
    result.focus({ preventScroll: true });
    result.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
  }

  function setStatus(msg, isError = false) {
    status.textContent = msg;
    status.classList.toggle("error", isError);
  }

  async function analyze() {
    const text = input.value.trim();
    if (!text) { setStatus("Paste a link or message first.", true); input.focus(); return; }
    go.disabled = true; setStatus("Analysing…");
    try {
      const res = await fetch("/api/analyze", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, expand_redirects: expand.checked }),
      });
      if (res.status === 429) { setStatus(`Too many requests. Try again in ${res.headers.get("Retry-After") || "a few"} seconds.`, true); return; }
      if (res.status === 413 || res.status === 422) { setStatus("That input is too large. Paste a shorter message (max 20,000 characters).", true); return; }
      if (!res.ok) { setStatus("Something went wrong on the server. Please try again.", true); return; }
      render(await res.json());
      setStatus("");
    } catch {
      setStatus("Could not reach the server. Check your connection and try again.", true);
    } finally {
      go.disabled = false;
    }
  }

  input.addEventListener("input", () => { counter.textContent = `${input.value.length.toLocaleString()} / ${MAX.toLocaleString()}`; });
  go.addEventListener("click", analyze);
  input.addEventListener("keydown", (e) => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter") analyze(); });
  clear.addEventListener("click", () => { input.value = ""; input.dispatchEvent(new Event("input")); result.hidden = true; result.replaceChildren(); setStatus(""); input.focus(); });
  document.querySelectorAll("[data-ex]").forEach((b) => b.addEventListener("click", () => {
    input.value = EXAMPLES[b.dataset.ex]; input.dispatchEvent(new Event("input")); analyze();
  }));

  fetch("/api/health").then((r) => r.json()).then((j) => { if (j.features && j.features.redirect_expansion) expandWrap.hidden = false; }).catch(() => {});
})();
