"""In-memory sliding-window rate limiter.

Mistake avoided: trusting the left-most X-Forwarded-For value. Clients can put anything there, which lets an
attacker dodge limits. We take the entry added by *our own* proxy (counted from the right).
"""
from __future__ import annotations

import time
from collections import defaultdict, deque

from fastapi import Request


def client_ip(request: Request, trusted_hops: int) -> str:
    if trusted_hops > 0:
        xff = request.headers.get("x-forwarded-for", "")
        chain = [p.strip() for p in xff.split(",") if p.strip()]
        if len(chain) >= trusted_hops:
            return chain[-trusted_hops]
    return request.client.host if request.client else "unknown"


class RateLimiter:
    def __init__(self, per_minute: int) -> None:
        self.per_minute = per_minute
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._last_sweep = time.monotonic()

    def allow(self, key: str) -> tuple[bool, int]:
        """Return (allowed, retry_after_seconds)."""
        if self.per_minute <= 0:
            return True, 0
        now = time.monotonic()
        window = self._hits[key]
        while window and now - window[0] > 60:
            window.popleft()
        if len(window) >= self.per_minute:
            return False, max(1, int(60 - (now - window[0])) + 1)
        window.append(now)
        if now - self._last_sweep > 300:  # drop idle keys so memory cannot grow without bound
            self._last_sweep = now
            for k in [k for k, v in self._hits.items() if not v or now - v[-1] > 60]:
                self._hits.pop(k, None)
        return True, 0
